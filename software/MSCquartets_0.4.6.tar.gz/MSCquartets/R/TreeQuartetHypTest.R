#' Power Divergence statistic of Cressie & Read
#'
#' Computes any of the family of power-divergence statistics of Cressie & Read (1984),
#' to compare observed and expected counts of observations. Includes Likelihood Ratio and Chi-squared statistics as special cases.
#' @param obs  observation vector
#' @param expd  expected vector
#' @param lambda  statistic parameter (0=Likelihood Ratio, 1=Chi-squared)
#'
#' @return value of statistic
#'
#' @export
power.div.stat <- function(obs, expd, lambda) {
  if (is.vector(obs) == FALSE ||
      is.vector(expd) == FALSE ||
      length(obs) != length(expd) ||
      min(obs) < 0 ||
      min(expd) < 0 ||
      is.vector(lambda) == FALSE || length(lambda) != 1) {
    # Return an error and stop if arguments are misspecified. If any expectations are 0 then the function fails.
    stop(
      "Invalid arguments: obs and expd must be non-negative vectors of the same length. lambda must be real."
    )
  }
  else{
    if (all.equal(sum(obs), sum(expd)) != TRUE)
    {
      diff = sum(obs) - sum(expd)
      warning(paste0(
        "sum(obs)-sum(expd) = ",
        diff,
        ", which is not within tolerance of 0."
      ))
    }
    if (all(obs == expd) == TRUE) {
      # If observations and expectations are equal, there is no need for an algorithm for computing the power-divergence statistic since the power-divergence statistic must be 0.
      stat  <- 0
    } else {
      if (lambda %in% c(0, 1,-1 / 2,-1,-2, 2 / 3) == FALSE) {
        warning(
          "Non-standard choice of lambda. Standard choices are lambda=0,1,-1/2,-1,-2,2/3."
        )
      }
      if (lambda == 0) {
        # If lambda=0, compute the likelihood ratio statistic.
        stat <- sum(ifelse(obs == 0, 0, 2 * obs * log(obs / expd)))
      } else if (lambda == -1) {
        # If lambda=-1, compute the modified likelihood ratio statistic.
        if (min(obs) == 0) {
          # If one of the observations is 0, then the modified likelihood statistic is undefined and an error is returned, advising the user to choose a different lambda.
          stop("Some observations are 0. Use any lambda other than lambda=-1.")
        } else {
          stat <- sum(2 * expd * log(expd / obs))
        }
      } else {
        # If lambda is anything other than 0 or -1, then the function in the limit is not required.
        stat <-
          sum((2 / (lambda * (lambda + 1))) * obs * ((obs / expd) ^ lambda -
                                                       1))
      }
    }
    return(stat)
  }
}

#########################################################

# Error function
#
#@param x argument
#@return function value
#
erf <- function(x) {
  2 * pnorm(x * sqrt(2)) - 1
}

#########################################################

# Inverse error function
#
#@param x argument
#@return function value
#
erf.inv <- function(x) {
  qnorm((x + 1) / 2) / sqrt(2)
}

#########################################################

#' Probability density function for Model T1 of [MAR19], Proposition 5.2
#'
#'@param x  statistic value (e.g., likelihood ratio stat, or other power divergence stat)
#'@param mu0  parameter
#'
#'@return value of density function
#'
#'@seealso \code{\link{T3density}}
#'
#'@importFrom RandomFieldsUtils I0L0
#'
#'@export
T1density <-
  function(x, mu0) {
    (1 / 4) * exp(-(1 / 2) * x) * (sqrt(2 / (pi * x)) * (1 + erf(mu0 / sqrt(2))) +
                                     exp(-(1 / 2) * mu0 ^ 2) * RandomFieldsUtils::I0L0(mu0 * sqrt(x)))
  }

#########################################################

#' Probability density function for Model T3 of [MAR19], Proposition 4.2
#'
#' @param x  statistic value (e.g., LR stat, or other power divergence stat)
#' @param mu0 parameter
#' @param alpha0 parameter
#' @param beta0 parameter
#'
#' @return  value of density function
#'
#' @seealso \code{\link{T1density}}
#'
#' @export
T3density <- function(x, mu0, alpha0, beta0) {
  (1 / (2 * sqrt(2 * pi * x))) * (exp(-(1 / 2) * x) * (1 - erf((1 / sqrt(
    2
  )) *
    (
      sqrt(x) * tan(beta0) - mu0
    ))) + exp(-(1 / 2) * (sqrt(x) - mu0 * cos(alpha0)) ^ 2) *
    (1 - erf((1 / sqrt(
      2
    )) * (
      sqrt(x) * tan(beta0) + mu0 * sin(alpha0)
    ))) +
    exp(-(1 / 2) * (sqrt(x) + mu0 * cos(alpha0)) ^ 2) * (1 - erf((1 / sqrt(
      2
    )) *
      (
        sqrt(x) * tan(alpha0) + mu0 * sin(alpha0)
      ))))
}

#########################################################

#' Hypothesis test for fit of a quartet counts to multispecies coalescent model.
#'
#' Test the hypothesis H_0= T1 or T3 model of [MAR19], vs. H_1 = everything else. This function implements two of
#' the versions of the test given in [MAR19] as well as parametric boostrapping, with other procedures for when some counts are small.
#' Due to the singularity and boundary of the models, when the topology and/or the internal
#' quartet branch length is unknown these are more accurate tests than, say, a chi-squared with one degree of freedom which 
#' assumes no model boundary or singularity near the data
#'
#' @details
#' If \code{method="MLtest"}, this uses the test by that name described in Section 7 of [MAR19]. For
#' model T1 this test is slightly anticonservative if the true internal edge of the quartet species tree is very
#' short. Although the test generally performs well in practice, it lacks a uniform asymptotic guarantee over the full parameter space. 
#' 
#' If \code{method="conservative"}, a more conservative test described in [MAR19] is used. For model T3 this uses the chi^2_1
#' distribution (the "least favorable" approach), while for model T1
#' it uses the Minimum Adjusted Bonferroni, based on precomputed values from simulations.
#' These conservative test are asymptotically guaranteed to reject the null
#' hypothesis at most at a specified level, but at the expense of increased type II errors.
#' 
#' If \code{method="bootstrap"}, then parametric bootsrapping is done, based on parameter estimates of the quartet topology 
#' and internal edge length.The bootstrap sample size is given by the \code{bootstrap} argument.
#'
#'
#' When some expected topology counts are small, the methods "MLest" and "conservative" are not appropriate.
#' The argument \code{smallcounts} determines whether bootstrapping or an approximate method that uses precomputed p-values is used.
#' These both involve estimates of the quartet topology and internal edge length.
#'
#' The returned p-value should be taken with caution when there is a small sample size, e.g. less than 30 gene trees.
#'
#' For model T1, the first entry of \code{obs} is treated as the count of gene quartets concordant with the species tree.
#'
#' The returned value of \code{t} is a consistent estimator, but not the MLE, of the internal 
#' edge length in coalescent units. Although consistent, the MLE for t is biased. 
#' Our consistent estimator is still biased, but with less bias than the MLE. See [MAR19] 
#' for more discussion on dealing with the bias of parameter estimates in the 
#' presence of boundaries and/or singularities of parameter spaces.
#'
#' @param obs  vector of 3 counts of resolved quartet frequncies,
#' @param model  "T1" or "T3", for the models of [MAR19],
#' @param lambda  parameter for power-divergence statistic (0 for LR stat, 1 for Chi-squared stat)
#' @param smallcounts "bootstrap" or "approximate", method of obtaining p-value when some counts are small
#' @param bootstraps  number of samples for bootstrapping
#' @param method "MLtest","conservative", or "bootstrap"
#'
#' @return \code{(p-value, t)} where \code{t} is a consistent estimator of the 
#' internal edge length in coalescent units, possibly \code{Inf}.
#'
#' @examples
#'  obs=c(17,72,11)
#'  QuartetTreeTest(obs,"T3")
#'  QuartetTreeTest(obs,"T1")
#'
#' @seealso \code{\link{MultiIndepQuartetTreeTest}}
#'
#' @importFrom stats pbinom rmultinom integrate pnorm uniroot
#'
#' @export
QuartetTreeTest <- function(obs,
                            model = "T3",
                            lambda = 0,
                            smallcounts = "approximate",
                            bootstraps = 10^4,
                            method = "MLest") {
  # Function for correcting the bias of the mu0 as much as possible for model T1
  T1bias <- function(mu02, mu0) {
    (1 / sqrt(2 * pi)) * exp(-(1 / 2) * mu02 ^ 2) + (1 / 2) * mu02 * (1 + erf(mu02 /
                                                                                sqrt(2))) - mu0
  }
  
  # Function to integrate for bias for model T3
  integrand <-
    function(y, mu02, alpha02, beta02) {
      (1 / sqrt(2 * pi)) * y * (exp(-(1 / 2) * (y - mu02) ^ 2) * erf(y * (1 / tan(beta02)) /
                                                                       sqrt(2)) + exp(-(1 / 2) * (y + mu02 * sin(alpha02)) ^ 2) * (erf((
                                                                         y * (1 / tan(alpha02)) + mu02 * cos(alpha02)
                                                                       ) / sqrt(2)) + erf((
                                                                         y * tan(alpha02 + beta02) - mu02 * cos(alpha02)
                                                                       ) / sqrt(2))))
    }
  
  # Function for correcting the bias of the mu0 as much as possible for model T3.
  T3bias <- function(mu02, mu0, n) {
    phi02 <-
      min((1 / (4 * (n + mu02 ^ 2))) * (4 * n + 3 * mu02 ^ 2 - mu02 * sqrt(8 *
                                                                             n + 9 * mu02 ^ 2)), 1)
    alpha02 <- atan(1 / sqrt(3 * (3 - 2 * phi02)))
    beta02 <- (1 / 2) * (pi / 2 - alpha02)
    bias <-
      integrate(
        integrand,
        lower = 0,
        upper = Inf,
        mu02 = mu02,
        alpha02 = alpha02,
        beta02 = beta02
      )$value - mu0
    return(bias)
  }
  
  if (is.vector(obs) == FALSE ||
      length(obs) != 3 ||
      min(obs) < 0 ||
      sum(obs) < 1 ||
      all.equal(sum(obs), round(sum(obs))) != TRUE ||
      model %in% c("T1", "T3") == FALSE ||
      is.vector(lambda) == FALSE ||
      length(lambda) != 1 ||
      smallcounts %in% c("bootstrap", "approximate") == FALSE ||
      bootstraps <= 0 || bootstraps %% 1 != 0 ||
      method %in% c("MLest", "conservative", "bootstrap") == FALSE) {
    # Return an error and stop if arguments are misspecified.
    stop(
      'Invalid arguments: obs must be a non-negative vector of length 3 summing to a positive integer;
      model must be "T1" or "T3"; lambda must be real; smallcounts must be "bootstrap" or "approximate";
      bootstraps must be a positive integer; method must be "MLest","conservative", or "bootstrap".'
    )
  } else {
    n <- sum(obs)
    if (n < 30) {
      # Provide a warning if there are a small number of gene trees.
      warning("The number of gene quartets is <30; p-value may be inaccurate.")
    }
    # compute ML estimate for obs
    if (model == "T3") {
      obs <- sort(obs, decreasing = TRUE)
      expd <-
        c(obs[1], (1 / 2) * (n - obs[1]), (1 / 2) * (n - obs[1]))
    } else {
      # assume model=T1
      expd <-
        c(max(obs[1], n / 3), (1 / 2) * (n - max(obs[1], n / 3)), (1 / 2) * (n - max(obs[1], n /
                                                                                       3)))
    }
    
    phi0 <- 3 * (n - expd[1]) / (2 * n)
    mu0 <-
      max(0, sqrt(2 * n) * (1 - phi0) / sqrt(phi0 * (3 - 2 * phi0)))
    if (min(expd) != 0) {
      if (model == "T1") {
        # Bias correction.
        if (mu0 <= 1 / sqrt(2 * pi)) {
          mu0unbiased <- 0
        } else if (sign(T1bias(0, mu0)) == sign(T1bias(mu0, mu0))) {
          # If the absolute bias is so small that absolute error may be bigger, then disregard bias.
          mu0unbiased <- mu0
        } else {
          mu0unbiased <- uniroot(T1bias, c(0, mu0), mu0 = mu0)$root
        }
        phi0unbiased <-
          (1 / (4 * (n + mu0unbiased ^ 2))) * (4 * n + 3 * mu0unbiased ^ 2 - mu0unbiased *
                                                 sqrt(8 * n + 9 * mu0unbiased ^ 2))
      }
      else {
        # Bias correction for model=T3.
        if (mu0 <= 3 * sqrt(3) / (2 * sqrt(2 * pi))) {
          mu0unbiased <- 0
        } else if (sign(T3bias(0, mu0, n)) == sign(T3bias(mu0, mu0, n))) {
          # If the absolute bias is so small that absolute error may be bigger, then disregard bias.
          mu0unbiased <- mu0
        } else {
          mu0unbiased <- uniroot(T3bias, c(0, mu0), mu0 = mu0, n = n)$root
        }
        phi0unbiased <-
          (1 / (4 * (n + mu0unbiased ^ 2))) * (4 * n + 3 * mu0unbiased ^ 2 - mu0unbiased *
                                                 sqrt(8 * n + 9 * mu0unbiased ^ 2))
        if (identical(obs, expd) == FALSE) {
          # For model T3 alpha0 and beta0 must also be computed if p-value is not 1.
          alpha0unbiased <-
            atan(1 / sqrt(3 * (3 - 2 * phi0unbiased)))
          beta0unbiased <- (1 / 2) * (pi / 2 - alpha0unbiased)
        }
      }
    } else {
      phi0unbiased <- phi0
    }
    t <- -log(phi0unbiased)
    if (all.equal(sum(abs(obs - expd)), 0) == TRUE) {
      # If all observations and expectations are equal, then the p-value must be 1.
      p <- 1
    } else {
      stat <- power.div.stat(obs, expd, lambda)
      
      if (method == "bootstrap" || (method != "bootstrap" && smallcounts == "bootstrap" && min(expd) < 5)) {
        # Perform bootstrap if bootstrap method is selected, or if bootstrap method is not selected but bootstrap for smallcounts is
        # selected and there are small expected counts.
        warning(
          "Bootstrapping has been selected. p-values are approximate. Bootstrapping is only necessary when some expectations are small."
        )
        # If bootstraps is 0 but bootstraps has been selected then perform 10^4 bootstraps.
        if (bootstraps == 0) {
          bootstraps <- 10 ^ 4
        }
        count <- 0
        sims <-
          rmultinom(bootstraps,
                    n,
                    prob = c(
                      1 - (2 / 3) * phi0unbiased,
                      (1 / 3) * phi0unbiased,
                      (1 / 3) *
                        phi0unbiased
                    ))
        if (model == "T3") {
          sims <- apply(sims, 2, sort, decreasing = TRUE)
        }
        for (i in 1:bootstraps) {
          if (model == "T3") {
            expected <-
              c(sims[1, i], (1 / 2) * (n - sims[1, i]), (1 / 2) * (n - sims[1, i]))
          } else {
            expected <-
              c(max(sims[, i], n / 3), (1 / 2) * (n - max(sims[, i], n /
                                                            3)), (1 / 2) * (n - max(sims[, i], n / 3)))
          }
          simstat <- power.div.stat(sims[, i], expected, lambda)
          count <- ifelse(simstat >= stat, count + 1, count)
        }
        p <- count / bootstraps
      } else if (method != "bootstrap" && smallcounts == "approximate" && min(expd) < 5) {
        # Approximate bootstrap p-values computed from 10^8 bootstraps for each scenario, with obs[1]=10^6. Fairly accurate approximation, even for obs[1]!=10^6.
        if (all.equal(sum(abs(obs * 3 - round(obs * 3))), 0) == TRUE) {
          sortobs23times3 = sort(round(3 * obs[2:3]))
          if (sortobs23times3[1] %% 3 == 0) {
            if (identical(sortobs23times3, c(0, 27))) {
              p <- 0.000919
            } else if (identical(sortobs23times3, c(3, 24))) {
              p <- 0.0209
            } else if (identical(sortobs23times3, c(6, 21))) {
              p <- 0.103
            } else if (identical(sortobs23times3, c(9, 18))) {
              p <- 0.359
            } else if (identical(sortobs23times3, c(12, 15))) {
              p <- 0.790
            } else if (identical(sortobs23times3, c(0, 24))) {
              p <- 0.00191
            } else if (identical(sortobs23times3, c(3, 21))) {
              p <- 0.0397
            } else if (identical(sortobs23times3, c(6, 18))) {
              p <- 0.175
            } else if (identical(sortobs23times3, c(9, 15))) {
              p <- 0.523
            } else if (identical(sortobs23times3, c(0, 21))) {
              p <- 0.00416
            } else if (identical(sortobs23times3, c(3, 18))) {
              p <- 0.0763
            } else if (identical(sortobs23times3, c(6, 15))) {
              p <- 0.297
            } else if (identical(sortobs23times3, c(9, 12))) {
              p <- 0.768
            } else if (identical(sortobs23times3, c(0, 18))) {
              p <- 0.00871
            } else if (identical(sortobs23times3, c(3, 15))) {
              p <- 0.129
            } else if (identical(sortobs23times3, c(6, 12))) {
              p <- 0.476
            } else if (identical(sortobs23times3, c(0, 15))) {
              p <- 0.0183
            } else if (identical(sortobs23times3, c(3, 12))) {
              p <- 0.240
            } else if (identical(sortobs23times3, c(6, 9))) {
              p <- 0.737
            } else if (identical(sortobs23times3, c(0, 12))) {
              p <- 0.0393
            } else if (identical(sortobs23times3, c(3, 9))) {
              p <- 0.439
            } else if (identical(sortobs23times3, c(0, 9))) {
              p <- 0.0860
            } else if (identical(sortobs23times3, c(3, 6))) {
              p <- 0.681
            } else if (identical(sortobs23times3, c(0, 6))) {
              p <- 0.197
            } else if (identical(sortobs23times3, c(0, 3))) {
              p <- 0.478
            }
          }
          else if (sortobs23times3[1] %% 3 == 1) {
            if (identical(sortobs23times3, c(1, 28))) {
              p <- 0.00222
            } else if (identical(sortobs23times3, c(4, 25))) {
              p <- 0.0237
            } else if (identical(sortobs23times3, c(7, 22))) {
              p <- 0.119
            } else if (identical(sortobs23times3, c(10, 19))) {
              p <- 0.358
            } else if (identical(sortobs23times3, c(13, 16))) {
              p <- 0.777
            } else if (identical(sortobs23times3, c(1, 25))) {
              p <- 0.00452
            } else if (identical(sortobs23times3, c(4, 22))) {
              p <- 0.0436
            } else if (identical(sortobs23times3, c(7, 19))) {
              p <- 0.203
            } else if (identical(sortobs23times3, c(10, 16))) {
              p <- 0.520
            } else if (identical(sortobs23times3, c(1, 22))) {
              p <- 0.00940
            } else if (identical(sortobs23times3, c(4, 19))) {
              p <- 0.0794
            } else if (identical(sortobs23times3, c(7, 16))) {
              p <- 0.295
            } else if (identical(sortobs23times3, c(10, 13))) {
              p <- 0.754
            } else if (identical(sortobs23times3, c(1, 19))) {
              p <- 0.0194
            } else if (identical(sortobs23times3, c(4, 16))) {
              p <- 0.143
            } else if (identical(sortobs23times3, c(7, 13))) {
              p <- 0.470
            } else if (identical(sortobs23times3, c(1, 16))) {
              p <- 0.0404
            } else if (identical(sortobs23times3, c(4, 13))) {
              p <- 0.233
            } else if (identical(sortobs23times3, c(7, 10))) {
              p <- 0.720
            } else if (identical(sortobs23times3, c(1, 13))) {
              p <- 0.0850
            } else if (identical(sortobs23times3, c(4, 10))) {
              p <- 0.422
            } else if (identical(sortobs23times3, c(1, 10))) {
              p <- 0.113
            } else if (identical(sortobs23times3, c(4, 7))) {
              p <- 0.665
            } else if (identical(sortobs23times3, c(1, 7))) {
              p <- 0.237
            } else if (identical(sortobs23times3, c(1, 4))) {
              p <- 0.532
            }
          }
          else {
            if (identical(sortobs23times3, c(2, 26))) {
              p <- 0.00827
            } else if (identical(sortobs23times3, c(5, 23))) {
              p <- 0.0436
            } else if (identical(sortobs23times3, c(8, 20))) {
              p <- 0.199
            } else if (identical(sortobs23times3, c(11, 17))) {
              p <- 0.516
            } else if (identical(sortobs23times3, c(2, 23))) {
              p <- 0.0164
            } else if (identical(sortobs23times3, c(5, 20))) {
              p <- 0.0777
            } else if (identical(sortobs23times3, c(8, 17))) {
              p <- 0.298
            } else if (identical(sortobs23times3, c(11, 14))) {
              p <- 0.739
            } else if (identical(sortobs23times3, c(2, 20))) {
              p <- 0.0237
            } else if (identical(sortobs23times3, c(5, 17))) {
              p <- 0.146
            } else if (identical(sortobs23times3, c(8, 14))) {
              p <- 0.466
            } else if (identical(sortobs23times3, c(2, 17))) {
              p <- 0.0468
            } else if (identical(sortobs23times3, c(5, 14))) {
              p <- 0.238
            } else if (identical(sortobs23times3, c(8, 11))) {
              p <- 0.703
            } else if (identical(sortobs23times3, c(2, 14))) {
              p <- 0.0926
            } else if (identical(sortobs23times3, c(5, 11))) {
              p <- 0.409
            } else if (identical(sortobs23times3, c(2, 11))) {
              p <- 0.185
            } else if (identical(sortobs23times3, c(5, 8))) {
              p <- 0.645
            } else if (identical(sortobs23times3, c(2, 8))) {
              p <- 0.377
            } else if (identical(sortobs23times3, c(2, 5))) {
              p <- 0.525
            }
          }
        } else {
          stop(
            'Approximate bootstrap p-values only available for observed counts that are integers, integers + 1/3, or integers + 2/3. Use bootstrap instead.'
          )
        }
      } else if (method != "bootstrapping" && min(expd) >= 5) {
        if (method == "MLest") {
          if (model == "T3") {
            # If model is model T3 then compute the p-value using the function T3density. Otherwise, use the function T1density.
            p <- ifelse(stat == 0,
                        1,
                        min(1, max(
                          0,
                          integrate(
                            T3density,
                            lower = stat,
                            upper = Inf,
                            mu0 = mu0unbiased,
                            alpha0 = alpha0unbiased,
                            beta0 = beta0unbiased
                          )$value
                        )))
          } else {
            # if model is T1
            p <- ifelse(stat == 0,
                        1,
                        min(1, max(
                          0,
                          integrate(
                            T1density,
                            lower = stat,
                            upper = Inf,
                            mu0 = mu0unbiased
                          )$value
                        )))
          }
        } else if (method == "conservative") {
          # Perform a test with controlled asymptotic size such that the null rejection rate does not exceed the nominal significance level.
          if (model == "T3") {
            # For model T3, the conservative test uses the least favorable approach, which in this case is the chi_1^2 distribution.
            p <- pchisq(stat, 1, lower.tail = FALSE)
          } else {
            # For model T1, the conservative test is the Minimum Adjusted Bonferroni method.
            pT1beta5 = NULL
            pT1beta20 = NULL
            pT1beta30 = NULL
            pT1beta45 = NULL
            pT1beta50 = NULL
            load(file = "pT1.RData") # read in the pT1betaXX tables computed from simulation
            if (mu0 >= 0 && mu0 <= 0.125) {
              beta <- 0.5
              q <- pT1beta50
            } else if (mu0 > 0.125 && mu0 <= 1.75) {
              beta <- 0.45
              q <- pT1beta45
            } else if (mu0 > 1.75 && mu0 <= 2.75) {
              beta <- 0.3
              q <- pT1beta30
            } else if (mu0 > 2.75 && mu0 <= 3.75) {
              beta <- 0.2
              q <- pT1beta20
            } else {
              beta <- 0.05
              q <- pT1beta5
            }
            mu0lower <-
              max(0, mu0 + sqrt(2) * erf.inv(2 * beta - 1))
            p1 <- ifelse(stat == 0,
                         1,
                         min(1, max(
                           0,
                           integrate(
                             T1density,
                             lower = stat,
                             upper = Inf,
                             mu0 = mu0lower
                           )$value
                         )))
            p <- (length(q[q <= p1])) / length(q)
          }
        }
      }
    }
    output <- list(p, t)
    names(output) <- c("p.value", "t")
    return(output)
  }
}


#########################################################

#' Mutiple independent hypothesis tests for quartet counts fitting multispecies coalescent model on a tree
#'
#' Perform hypothesis test for tree for all quartets in a table, as if the quartets are independent. Assumes all quartets are resolved.
#' The test performed is described in more detail in \code{QuartetTreeTest} and fully in the [MAR19].
#'
#' @param T  table of resolved quartet counts, as produced by \code{ResolvedQuartetTable}, or \code{MultiIndepQuartetStarTest}
#' @param model  "T1" or "T3", for the models of [MAR19]
#' @param lambda power divergence statistic parameter (0 for likelihood ratio stat)
#' @param smallcounts "bootstrap" or "approximate", method of obtaining p-value when some counts are small
#' @param bootstraps  number of samples for bootstrapping
#' @param method "MLest", "conservative", or "bootstrap"
#' @param speciestree  species tree, in Newick as text, to determine quartet for T1 test; required for \code{model}="T1", ignored for \code{model}="T3"
#' @return
#'   If \code{model}="T3", a copy of T with a new column "p_T3" appended with p-values for each quartet;
#'   If \code{model}="T1", a copy of T with 2 columns appended: "p_T1" with p-values, and "qindex" giving index of quartet consistent
#'               with specified species tree, i.e., 1 if ab|cd on species tree, 2 if ac|bd, 3 if ad|bc
#'
#' @seealso \code{\link{QuartetTreeTest}}, \code{\link{PlotQuartetTest}}, \code{\link{MultiIndepQuartetStarTest}}, \code{\link{ResolvedQuartetTable}}
#'
#' @examples
#' gtrees=read.tree(file=system.file("genetreeSample",package="MSCquartets"))
#' taxanames=AllTaxonNames(gtrees)
#' QT=QuartetTable(gtrees,taxanames)
#' RQT=ResolvedQuartetTable(QT)
#' pTable3=MultiIndepQuartetTreeTest(RQT,"T3")
#' pTable3
#' stree="((a,b),(c,(d,e)));"
#' pTable1=MultiIndepQuartetTreeTest(RQT,"T1",speciestree=stree)
#' pTable1
#' 
#' @importFrom ape unroot read.tree cophenetic.phylo
#' @export
MultiIndepQuartetTreeTest <-
  function(T,
           model = "T3",
           lambda = 0,
           smallcounts = "approximate",
           bootstraps = 10^4,
           method = "MLest",
           speciestree = NULL) {
    M = dim(T)[1] # number of quartets
    n = dim(T)[2] # number of taxa + 3
    
    if (model == "T3") {
      pTable = cbind(T, p_T3 = 0) # create table for quartets, counts, and p-values
      cat("Applying hypothesis test for model T3 to",M,"quartets.\n")
      for (m in 1:M) {
        # consider each quartet
        obs = unname(T[m, (n - 2):n])
        pvec = QuartetTreeTest(
          obs,
          model,
          lambda = lambda,
          smallcounts = smallcounts,
          bootstraps = bootstraps,
          method = method
        )  #  compute p-value
        pTable[m, "p_T3"] = pvec$p.value  # store p-value
      }
    } else {
      if (model != "T1") {
        stop("Invalid model: must use 'T1' or 'T3'")
      } else {
        if (is.null(speciestree)) {
          stop("Species tree topology must be supplied for model T1")
        } else {
          stree = unroot(read.tree(text = speciestree)) #unrooted species tree
          nedges = dim(stree$edge)[1]# number of edges
          stree$edge.length = rep(1, nedges)# reset edge lengths to 1
          D = cophenetic.phylo(stree) # create distance table, for determining displayed quartets
          D = D[order(rownames(D)), order(colnames(D))]# put taxa in sorted order
          pTable = cbind(T, p_T1 = 0, qindex = 0) # create table for quartets, counts, p-values, index for quartet on species tree
          
          cat("Applying hypothesis test for model T1 to",M,"quartets.\n")
          for (m in 1:M) {
            # consider each quartet
            qnames = which(T[m, 1:(n - 3)] == 1) # determine taxa to in this quartet
            a = D[qnames[1], qnames[2]] + D[qnames[3], qnames[4]] # use four point condition on species tree
            b = D[qnames[1], qnames[3]] + D[qnames[2], qnames[4]]
            c = D[qnames[1], qnames[4]] + D[qnames[2], qnames[3]]
            squartet = which.min(c(a, b, c)) #                      to determine quartet on species tree
            qcounts = T[m, (n - 2):n]
            temp = qcounts[1]# interchange
            qcounts[1] = qcounts[squartet]# to put quartet on species tree first
            qcounts[squartet] = temp
            pTable[m, "qindex"] = squartet # save index of quartet on species tree
            pvec = QuartetTreeTest(
              unname(qcounts),
              model,
              lambda = lambda,
              smallcounts = smallcounts,
              bootstraps = bootstraps
            )  #  compute p-value
            pTable[m, "p_T1"] = pvec$p.value  # store p-value
          }
        }
      }
    }
    return(pTable)
  }

#############################################################

#' Produce simplex plot of results of MultiIndepQuartetTreeTest, MultiIndepQuartetStarTest, or NANUQ
#'
#' Plot is of 2-d simplex, with points for all quartet count vectors. Color of point indicates rejection or failure to reject of tests,
#' at specified level.
#'
#' @details This function must be supplied with a table of quartets and p-values. The plot may show results of either the T1 or T3
#' test, with or without a star tree test. The p-values must be supplied by previous calls to
#' \code{MultiIndepQuartetTreeTest} (for T1 or T3 p-values) and \code{MultiIndepQuartetStarTest} (for star tree). The \code{NANUQ}
#' functions include calls for the T3 and star tests
#'
#' @param pTable table of quartets and p-values, as produced by \code{MultiIndepQuartetTreeTest} (extra columm if model=T1), \code{MultiIndepQuartetStarTest}, or \code{NANUQ}
#' @param test  model to use, options are "T1", "T3" (NANUQ uses "T3")
#' @param alpha  significance level  for H0="T1" or "T3" test
#' @param beta  significance level for H0=star tree test (test shown only if \code{beta<1})
#'
#' @return None
#'
#' @seealso \code{\link{MultiIndepQuartetTreeTest}}, \code{\link{MultiIndepQuartetStarTest}},
#' \code{\link{NANUQ}},\code{\link{NANUQdist}}
#'
#' @examples
#' gtrees=read.tree(file=system.file("genetreeSample",package="MSCquartets"))
#' taxanames=AllTaxonNames(gtrees)
#' QT=QuartetTable(gtrees,taxanames)
#' RQT=ResolvedQuartetTable(QT)
#' stree="((a,b),(c,(d,e)));"
#' pTable=MultiIndepQuartetTreeTest(RQT,"T1",speciestree=stree)
#' pTable=MultiIndepQuartetStarTest(pTable)
#' PlotQuartetTest(pTable, "T1", alpha=.05, beta=.95)
#'
#' @export
PlotQuartetTest <- function(pTable,
                            test,
                            alpha = 0,
                            beta = 1) {
  if (!(is.numeric(alpha) && is.numeric(beta))) {
    stop("Critical values alpha and beta must be numeric.")
  }
  lineWidth = 1.5
  yellowColor = "goldenrod3" #pick specific colors
  orangeColor = "darkgreen"
  redColor = "red"
  blueColor = "blue"
  
  counts = c("12|34", "13|24", "14|23")
  M = dim(pTable)[1]
  n = dim(pTable)[2]
  
  if ((test == "T1") & (beta == 1)) {
    #  T1 only
    p_tree.small = (pTable[, "p_T1"] < alpha)
    p_star.small = rep(TRUE, M)
    titletext = bquote("Model T1," ~ alpha * "=" * .(alpha))
    legtext = c("reject tree", "fail to reject tree")
    legpch = c(2, 1)
    legcol = c(redColor, blueColor)
    model = "T1"
    #  for model 1 need to adjust point to reflect species tree
    for (m in 1:M) {
      qind = pTable[m, "qindex"]
      if (qind == 3) {
        pTable[m, counts] = pTable[m, counts[c(3, 1, 2)]]
      } else {
        if (qind == 2) {
          pTable[m, counts] = pTable[m, counts[c(2, 3, 1)]]
        }
      }
    }
  } else {
    if ((test == "T1") & (beta < 1)) {
      #  T1  and star
      p_tree.small = (pTable[, "p_T1"] < alpha)
      p_star.small = (pTable[, "p_star"] <= beta)
      titletext = bquote("Model T1," ~ alpha * "=" * .(alpha) * "," ~ beta *
                           "=" * .(beta))
      legtext = c(
        "reject tree & star",
        "fail to reject tree/reject star",
        "fail to reject tree & star",
        "reject tree/fail to reject star"
      )
      legpch = c(2, 1, 0, 4)
      legcol = c(redColor, blueColor, yellowColor, orangeColor)
      model = "T1"
      #  for model 1 need to adjust point to reflect species tree
      for (m in 1:M) {
        qind = pTable[m, "qindex"]
        if (qind == 3) {
          pTable[m, counts] = pTable[m, counts[c(3, 1, 2)]]
        } else {
          if (qind == 2) {
            pTable[m, counts] = pTable[m, counts[c(2, 3, 1)]]
          }
        }
      }
    } else{
      if ((test == "T3") & (beta==1)) {
        #T3 only
        p_tree.small = (pTable[, "p_T3"] < alpha)
        p_star.small = rep(TRUE, M)
        titletext = bquote("Model T3," ~ alpha * "=" * .(alpha))
        legtext = c("reject tree", "fail to reject tree")
        legpch = c(2, 1)
        legcol = c(redColor, blueColor)
        model = "T3"
      } else {
        if ((test == "NANUQ") | ((test=="T3") & (beta<1))  ){
          #T3 and star
          p_tree.small = (pTable[, "p_T3"] < alpha)
          p_star.small = (pTable[, "p_star"] <= beta)
          
          if (test=="NANUQ"){
          titletext = bquote("NANUQ," ~ alpha * "=" * .(alpha) * "," ~ beta *
                               "=" * .(beta))
          } else {
            titletext = bquote("Model T3," ~ alpha * "=" * .(alpha) * "," ~ beta *
                               "=" * .(beta))
          }
          legtext = c(
            "reject tree & star",
            "fail to reject tree/reject star",
            "fail to reject tree & star",
            "reject tree/fail to reject star"
          )
          legpch = c(2, 1, 0, 4)
          legcol = c(redColor, blueColor, yellowColor, orangeColor)
          model = "T3"
        } else {
          stop("Invalid test name")
        }
      }
    }
  }

  
  SPrepare(model, maintitle="Quartet Hypothesis Test", titletext=titletext) # draw outline of simplex and lines for model
  
  blues = (!p_tree.small) & (p_star.small)
  reds = (p_tree.small) & (p_star.small)
  yellows = (!p_tree.small) & (!p_star.small)
  oranges = (p_tree.small) & (!p_star.small)
  
  bluepoints = pTable[which(blues), counts, drop = FALSE] # points to plot blue
  nblue = dim(bluepoints)[1]
  redpoints = pTable[which(reds), counts, drop = FALSE] #      red
  nred = dim(redpoints)[1]
  yellowpoints = pTable[which(yellows), counts, drop = FALSE] #      yellow
  nyellow = dim(yellowpoints)[1]
  orangepoints = pTable[which(oranges), counts, drop = FALSE] #        orange
  norange = dim(orangepoints)[1]
  
  if (nblue > 0) {
    for (i in 1:nblue) {
      SPoint(
        bluepoints[i,],
        type = "o",
        pch = 1,
        col = blueColor,
        lwd = lineWidth
      )
    }
  }
  if (nred > 0) {
    for (i in 1:dim(redpoints)[1]) {
      SPoint(
        redpoints[i,],
        type = "o",
        pch = 2,
        col = redColor,
        lwd = lineWidth
      )
    }
  }
  if (nyellow > 0) {
    for (i in 1:dim(yellowpoints)[1]) {
      SPoint(
        yellowpoints[i,],
        type = "o",
        pch = 0,
        col = yellowColor,
        lwd = lineWidth
      )
    }
  }
  if (norange > 0) {
    print("Some points (orange) accepted as star, but rejected as tree")
    for (i in 1:dim(orangepoints)[1]) {
      SPoint(
        orangepoints[i,],
        type = "o",
        pch = 4,
        col = orangeColor,
        lwd = lineWidth
      )
    }
  }
  legend(
    'topleft',
    legend = legtext,
    pch = legpch,
    col = legcol,
    cex = 0.8,
    inset = 0.01,
    pt.cex = 1.2,
    lty = 0,
    lwd = 2)
}


#########################################

#' Bayesian posterior probability of error in 4-taxon unrooted species tree topology estimate
#'
#' Bayesian posterior probability that ML estimate of 4-taxon species tree topology
#' from gene quartet topology counts is incorrect, under the assumption that the counts arises
#' from some species tree. Uses Jeffreys prior for internal branch length, and uniform prior 
#' on the resolved topology.
#'
#'@param obs vector of counts for 3 topologies
#'@param model "T3" or "T1", for the models of [MAR19] describing an unspecified species 
#'tree topology ("T3"), or the topology corresponding to the first entry of \code{obs} ("T1")
#'
#'@return posterior probability
#'
#'
#'@examples
#' obs <- c(28,32,30)
#' QuartetTreeErrorProb(obs,model="T1")
#' QuartetTreeErrorProb(obs,model="T3")
#'
#'@importFrom zipfR Ibeta
#'  
#'@export
QuartetTreeErrorProb <- function(obs,
                                 model = "T3") {
  
  if (is.vector(obs) == FALSE ||
      length(obs) != 3 ||
      min(obs) < 0 ||
      model %in% c("T1", "T3") == FALSE) {
    stop(
      'Invalid arguments: obs must be an non-negative vector of length 3, model must be "T1" or "T3".'
    )
  } else {
    # If all observations are equal, then all tree topologies have equal probabilities and quartet tree
    # error probability is 2/3.
    if (all.equal(obs[1],obs[2])==TRUE&&all.equal(obs[1],obs[3])==TRUE&&all.equal(obs[2],obs[3])==TRUE) {
      treeerrorprob <- 2/3
    } else {
      # Make the maximum likelihood tree topology the first if it isn't already.
      if (model == "T3") {
        obs <- sort(obs,decreasing=TRUE)
      }
      # Compute posterior probabilities for each topology. Prior probabilities for each tree topology
      # are 1/3 and the Jeffreys prior is used for phi0.
      logp1 <- obs[1]*log(2)+zipfR::Ibeta(2/3,obs[2]+obs[3]+1/2,obs[1]+1/2,log=TRUE)
      logp2 <- obs[2]*log(2)+zipfR::Ibeta(2/3,obs[1]+obs[3]+1/2,obs[2]+1/2,log=TRUE)
      logp3 <- obs[3]*log(2)+zipfR::Ibeta(2/3,obs[1]+obs[2]+1/2,obs[3]+1/2,log=TRUE)
      
      b1 <- exp(logp2-logp1)
      b2 <- exp(logp3-logp1)
      
      p1 <- 1/(1+b1+b2)
      p2 <- b1/(1+b1+b2)
      p3 <- b2/(1+b1+b2)
      
      treeerrorprob <- p2+p3
      
    }
    return(treeerrorprob)
  }
}


#############################################################################

#' Adjust p-values for multiple tests by Holm-Bonferroni method
#'
#' When p-values are computed for each quartet using
#' \code{MultiIndepQuartetTest} or \code{MultiIndepStarTest},
#' multiple comparisons are being done for one dataset. The 
#' Holm-Bonferroni method adjusts these p-values upward, 
#' controlling the familywise error rate. The probability 
#' of at least one false discovery is no more than the 
#' significance level.
#'
#' @param pTable a table of quartets with p-values, as computed by
#' \code{MultiIndepQuartetTest} or \code{MultiIndepStarTest}
#' @param columnname a name of a column of pTable containing p-values, such as "p_T3","p_T1","p_star"
#' @param alpha a critcal value, for rejection of adjusted p-values below alpha
#' @return the same table, with rows reordered, and 2 new columns of 1) adjusted p-values,
#' and 2) "Y" or "N" for reject/fail to reject
#'
#' @seealso \code{\link{MultiIndepQuartetTreeTest}}, \code{\link{MultiIndepQuartetStarTest}}
#'
#' @examples
#' gtrees=read.tree(file=system.file("genetreeSample",package="MSCquartets"))
#' taxanames=AllTaxonNames(gtrees)
#' QT=QuartetTable(gtrees,taxanames)
#' RQT=ResolvedQuartetTable(QT)
#' pTable=MultiIndepQuartetTreeTest(RQT,"T3")
#' HBpTable=HolmBonferroni(pTable,"p_T3",.05)
#' HBpTable
#'
#' @export
HolmBonferroni <- function(pTable, columnname, alpha) {
  m = nrow(pTable)
  pTable <-
    pTable[order(pTable[, columnname]),] #sort rows of table by columname
  multipliers <- m:1 # descending integers
  HBps <-
    pmin(1, pTable[, columnname] * multipliers) #adjust p-values
  FirstNonFail = min(c(which(HBps > alpha), m + 1))
  Reject = c(rep("Y", FirstNonFail - 1), rep("N", m - FirstNonFail + 1))
  newcols = cbind(HBps, Reject)
  pname = paste0("HB", columnname)
  colnames(newcols) = c(pname, paste0("Reject(", pname, ")"))
  pTable = cbind(pTable, newcols)
  return(pTable)
}
