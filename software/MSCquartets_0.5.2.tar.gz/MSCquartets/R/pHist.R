#' Plot histogram of log p-values in table
#'
#' Graphical exploration of extreme p-values from quartet hypothesis tests, to aid in choosing critical values
#' for use in NANUQ algorithm. Log base 10 of p-values exceeding some minimum are plotted, to explore gaps in 
#' the tail of the distribution.
#'
#'@param pTable a quartet table with p-values such as from \code{quartetTreeTestInd}
#'       or from \code{quartetStarTestInd}
#'@param model  one of "T1", "T3", or "star", where pTable contains a column \code{p_model} of p-values
#'@param pmin include only p-values above \code{pmin}
#'
#'@examples
#' pTable=NANUQ(system.file("extdata","dataYeastRokas",package="MSCquartets"), alpha=0, beta=.95)
#' pvalHist(pTable,"T3")
#' NANUQdist(pTable, alpha=10^-5, beta=.95)
#' NANUQdist(pTable, alpha=10^-3, beta=.95)

#'
#'@export
pvalHist = function(pTable, model, pmin = 0) {
  if (!(model %in% c("T1","T3","star"))) {
    stop('Argument model must be one of "T1", "T3", or "star".')
  }
  pcol=paste0("p_",model) 
  if (!(pcol %in% colnames(pTable))) {
    stop(c('Argument pTable has no column ',pcol,'.'))
  }
  pvals = pTable[, pcol]
  vals = pvals[which(pvals >= pmin)]
  par(mar = c(5.1, 4.1, 4.1, 2.1))# set margin
  hist(log10(vals),
       main = bquote("Histogram of log"[10] * "(" * .(pcol) * "), " * .(pcol) >
                       .(pmin)))
}
