#' Apply NANUQ network inference algorithm to Newick gene trees in a file
#'
#' The NANUQ algorithm of [ABR19] infers a hybridization network from a collection of gene trees,
#' under the level-1 network multispecies coalescent (NMSC) model. This function 1) counts displayed quartets across gene trees,
#' 2) applies appropriate hypothesis tests to judge quartet CFs as representing putative hybridization,
#' resolved trees, or unresolved (star) trees using alpha and beta as significance levels
#' and 3) computes the appropriate distance
#' tables under the level-1 network quartet distance, writing it to a file. This distance table file
#' can then be opened in SplitsTree to
#' obtain a circular split system under the Neighbor-Net algorithm, which is then depicted as a splits graph.
#' The splits graph should be interpretted via
#' the theory in [ABR19] to infer the level-1 species network, or to conclude the data does
#' not arise from the NMSC on such a network.
#'
#' @details In most instances of NANUQ, an initial call to \code{NANUQ} will not give a good analysis, as values
#' of \code{alpha} and \code{beta} are likely to need some adjustment based on inspecting the data. Saving the returned
#' table from \code{NANUQ} will allow for the results of the time-consuming computation of quartet counts and p-values to be saved,
#' for input to further calls of \code{NANUQ} with new choices of \code{alpha} and \code{beta}.
#' 
#' A call of NANUQ with \code{genedata} given as a table previously output from NANUQ is equivalent to a call of \code{NANUQdist}.
#'
#' If plots are produced, each point represents an empirical quartet concordance factor,
#' color-coded to represent test results
#'
#' @param genedata gene tree data that may be supplied in one of 3 ways: 1) as a character string giving the name of a file containing Newick gene trees,
#' 2) as a multiPhylo object containing the gene trees, or 3) as a table of quartets on the gene trees, as produced by a previous call to \code{NANUQ} 
#' or \code{ResolvedQuartetTable}
#' @param outfile  an output file name stub, to which will be appended an alpha value and ".nex", for saving the NANUQ distance matrix
#' @param alpha a vector of significance levels for judging p-values indicating hybridization on quartet, one for each output file; smaller values mean fewer calls of hybridization
#' @param beta a vector of significance levels for judging p-values indicating star quartet tree, one for each output file; smaller values result in fewer calls of resolved tree;
#' alpha and beta should be vectors of the same length
#' @param taxanames a subset of taxa on the gene trees, which will be the only ones analyzed; if NULL all taxa on the first gene tree are used
#' @param plot TRUE produces simplex plots of hypothesis test results, FALSE omits plots
#'
#' @return a table of quartets and p-values for judging fit to MSC on tree;
#' this table can be used as input to NANUQdist with new choices of alpha and beta, without re-tallying quartets on the
#' gene trees. A distance table to be used as input for SplitsTree is written to a nexus file.
#'
#'
#' @seealso \code{\link{QuartetTable}}, \code{\link{DominantQuartetTable}}, \code{\link{MultiIndepQuartetTreeTest}}, 
#' \code{\link{MultiIndepQuartetStarTest}}, \code{\link{NANUQdist}}
#'
#' @examples
#' pTable=NANUQ(system.file("yeastRokas",package="MSCquartets"), alpha=.0001, beta=.95)
#' NANUQ(pTable, alpha=.05, beta=.95)
#'
#' @export
NANUQ = function( genedata,
                  outfile = "NANUQdist",
                  alpha = .05,
                  beta = .95,
                  taxanames = NULL,
                  plot = TRUE) {
  if (!(class(genedata) %in% c("multiPhylo","character","matrix"))) {
    stop("Data must be supplied as an object of type multiPhylo, character, or matrix.")
  }
  if (!(is.numeric(alpha) && is.numeric(beta))) {
    stop("Critical values alpha and beta must be numeric.")
  }
  
  
  if (class(genedata)=="matrix" ) {
    pTable=genedata
  } else {
    if (class(genedata)=="multiPhylo") {
    genetrees = genedata
  } else {
    if (class(genedata)=="character")
    genetrees <- read.tree(genedata) #read gene trees
    cat(paste("Read", length(genetrees), "gene trees from file.\n"))
  }
 
  if (is.null(taxanames)) {
    # if no taxa names specified,
    taxanames = genetrees[[1]]$tip.label   # ... get them from first tree
  }
  taxanames = sort(taxanames)
  if (length(taxanames)<=25) {
  cat("Analyzing ",length(taxanames)," taxa:",paste(taxanames),"\n")
  } else {
  cat("Analyzing ",length(taxanames)," taxa:",paste(taxanames[1:25]),"...(see output table for full list)\n")  
  }
  
  pTable = QuartetTable(genetrees,taxanames)   # tally quartets on gene trees
  pTable = ResolvedQuartetTable(pTable, omit = FALSE)         # treat unresolved quartets as 1/3 of each resolution
  }
  
  if (!("p_T3"%in% colnames(pTable))){
    pTable = MultiIndepQuartetTreeTest(pTable, model = "T3", lambda = 0) # compute p-values for quartet CFs fit to MSC on a tree
  }
  
  if (!("p_star"%in% colnames(pTable))) {
  pTable = MultiIndepQuartetStarTest(pTable)# compute p-values for each quartet CFs fit to star tree
  }
  
  NANUQdist(pTable, outfile, alpha, beta, plot) # construct distance tables and put in files
  
  invisible(pTable)
}

####################################################################################################

#' Compute NANUQ distance and write to file
#'
#' Computes the quartet distance tables for NANUQ of [ABR19], using precomputed p-values for quartets,
#' for each of several levels specified. Distance tables are written to files, in nexus format.
#'
#' @details
#' If plots are produced, each point represents an empirical quartet concordance factor,
#' color-coded to represent test results giving interpretation as network, resolved tree, or star tree.
#'
#' If \code{alpha} and \code{beta} are vectors, they must be of same length k, in which case k distance
#' tables/plots are produced.
#'
#' @param pTable a table of quartets and p-values, as computed by NANUQ, or by MultiIndepQuartetTreeTest and MultiIndepQuartetStarTest, with columns "p_T3" and "p_star"
#' @param outfile  an output file name stub, to which will be appended alpha and beta values and ".nex", for saving distance matrix
#' @param alpha significance level for judging p_T3 indicating hybridization on quartet; smaller values mean fewer calls of hybridization
#' @param beta significance level for judging p_star indicating star quartet tree; smaller values result in fewer calls of resolved tree
#' @param plot TRUE produces simplex plots of hypothesis tests, FALSE omits plots
#'
#' @return None
#' @seealso \code{\link{NANUQ}}, \code{\link{MultiIndepQuartetTreeTest}}, \code{\link{MultiIndepQuartetStarTest}}
#'
#' @examples
#' pTable=NANUQ(system.file("yeastRokas",package="MSCquartets"), alpha=.0001, beta=.95)
#' NANUQdist(pTable, alpha=.05, beta=.95)
#'
#' @export
NANUQdist = function (pTable,
                      outfile = "NANUQdist",
                      alpha,
                      beta,
                      plot = TRUE) {
  if (!(is.numeric(alpha) && is.numeric(beta))) {
    stop("Critical values alpha and beta must be numeric.")
  }
  n = length(alpha)
  if (length(beta) != n)
    stop("alpha and beta must have same length")
  for (i in 1:n) {
    if (plot == TRUE) {
      PlotQuartetTest(pTable, "NANUQ", alpha[i], beta[i]) # plot quartets in simplex, indicating which are interpretted as hybridization
    }
    
    QD = QNdist(pTable, alpha[i], beta[i])           # compute the quartet distance table
    
    
    outfile1 = paste0(outfile, "_alpha", alpha[i], "_beta", beta[i], ".nex")  # name of the nexus output file
    NexusDist(QD, outfile1)           # Produce the file to be read by SplitsTree
  }
}

##################################################################################

#' Write a distance table to a file in nexus format
#'
#' @param D a square matrix giving a distance table, with rows and columns labeled by taxon names
#' @param outfilename the name of an output file
#'
#' @return None
#'
#' @export
NexusDist = function(D, outfilename) {
  taxanames = colnames(D)
  ntaxa = length(taxanames)
  taxanames = matrix(taxanames, ntaxa, 1)
  sink(outfilename)
  cat("#nexus\n BEGIN Taxa;\n DIMENSIONS ntax=",
      ntaxa,
      ";\n TAXLABELS\n")
  cat(paste(taxanames, "\n"))
  cat(
    ";\n END;\n \n BEGIN Distances; \n DIMENSIONS ntax=",
    ntaxa,
    "; \n FORMAT labels=left diagonal triangle=both;\n MATRIX\n"
  )
  cat(t(cbind(taxanames, D)))
  cat("; \n END;")
  sink()
 cat(paste("NANUQ distance table written to file:", outfilename,"\n"))
}

############################################################################


#' Produce network quartet distance table for NANUQ, as in [ABR19], from a table of p-values and specified levels
#'
#' @param pTable a table of quartets and p-values, as computed by NANUQ, or
#' \code{MultiIndepQuartetTreeTest} and \code{MultiIndepQuartetStarTest}
#' @param alpha0 a scalar significance level for judging p_T3 indicating hybridization on quartet;
#'      smaller value gives fewer hybridization calls
#' @param beta0 a scalar significance level for judging p_star indicating star quartet tree;
#'      smaller value gives fewer resolved tree calls
#'
#' @return a NANUQ distance table
#'
#' @seealso \code{\link{NANUQ}}, \code{\link{NANUQdist}}
#'
#' @export
QNdist = function(pTable, alpha0, beta0) {
  if (!(is.numeric(alpha0) && is.numeric(beta0))) {
    stop("Critical values alpha0 and beta0 must be numeric.")
  }
  d = dim(pTable)
  
  M = d[1] # number of quartet concordance factors
  ntaxa = d[2] - 5 #number of taxa
  
  taxanames = colnames(pTable)[1:ntaxa]  #names of taxa
  qnames = c("12|34", "13|24", "14|23")
  
  Qdist = matrix(0, ntaxa, ntaxa)
  #alocates space for dissimilarity matrix
  rownames(Qdist) = taxanames
  colnames(Qdist) = taxanames
  
  for (m in 1:M) {
    # consider each set of 4 taxa
    
    taxanums = which(pTable[m, 1:ntaxa] == 1) #determine taxa
    qcounts = pTable[m, qnames] # get counts
    
    if (pTable[m, "p_star"] > beta0) {
      # if quartet judged as star tree
      Qdist[taxanums, taxanums] = Qdist[taxanums, taxanums] + 1 #  it separates all taxa
    } else {
      qcountspr = qcounts + runif(3) * .0001 # introduce random tie breaking
      majorq = which.max(qcountspr) #determine quartet with largest count
      if (pTable[m, "p_T3"] > alpha0) {
        # if high p-value indicates tree
        if (majorq == 1) {
          Qdist[taxanums[1:2], taxanums[3:4]] = Qdist[taxanums[1:2], taxanums[3:4]] +
            1
        } else {
          if (majorq == 2) {
            Qdist[taxanums[c(1, 3)], taxanums[c(2, 4)]] = Qdist[taxanums[c(1, 3)], taxanums[c(2, 4)]] +
              1
          } else {
            Qdist[taxanums[c(1, 4)], taxanums[c(2, 3)]] = Qdist[taxanums[c(1, 4)], taxanums[c(2, 3)]] +
              1
          }
        }
      } else {
        # if low p-value indicates cycle
        minorq = which.min(qcountspr)
        middleq = setdiff(1:3, c(majorq, minorq))
        if (majorq == 1 || middleq == 1) {
          Qdist[taxanums[1:2], taxanums[3:4]] = Qdist[taxanums[1:2], taxanums[3:4]] +
            .5
        }
        if (majorq == 2 || middleq == 2) {
          Qdist[taxanums[c(1, 3)], taxanums[c(2, 4)]] = Qdist[taxanums[c(1, 3)], taxanums[c(2, 4)]] + .5
        }
        if (majorq == 3 || middleq == 3) {
          Qdist[taxanums[c(1, 4)], taxanums[c(2, 3)]] = Qdist[taxanums[c(1, 4)], taxanums[c(2, 3)]] + .5
        }
      }
    }
  }
  Qdist = Qdist + t(Qdist)
  Qdist = 2 * Qdist + 2 * ntaxa - 4 # adjust to get appropriate distances off-diagonal
  Qdist = Qdist - diag(diag(Qdist)) # but reset diagonal to 0
  
  return(Qdist)
}
