#' Mutiple independent hypothesis tests for gene quartet counts fitting a star tree under the multispecies coalescent model
#'
#' Perform hypothesis test for star tree for all quartet counts in an input table, as if the quartets are independent.
#' Assumes all quartets are resolved. The test performed is described in \code{QuartetTreeTest}.
#'
#' @param T  Table of resolved quartet counts, as produced by \code{ResolvedQuartetTable}, or \code{MultiIndepQuartetTreeTest}
#'
#' @return The same table as the input \code{T} with column "p_star" appended, containing p-values for judging fit to MSC on star tree
#'
#' @seealso \code{\link{QuartetStarTest}}, \code{\link{QuartetTreeTest}}, \code{\link{MultiIndepQuartetTreeTest}},
#' \code{\link{ResolvedQuartetTable}}, \code{\link{PlotQuartetTest}}
#'
#' @examples
#' gts=read.tree(file=system.file("genetreeSample",package="MSCquartet"))
#' taxanames=AllTaxa(gts)
#' QT=QuartetTable(taxanames,gts)
#' RQT=ResolvedQuartetTable(QT)
#' MultiIndepQuartetStarTest(RQT)
#'
#' @export
MultiIndepQuartetStarTest = function(T) {
  M = dim(T)[1]
  qcols = c("12|34", "13|24", "14|23")
  T = cbind(T, p_star = 0)
  
  for (i in 1:M) {
    obs = T[i, qcols] # get quartet counts
    T[i, "p_star"] = QuartetStarTest(obs) # store p-value for H0=star tree
  }
  return(T)
}

#' Hypothesis tests for quartet counts fitting star tree multispecies coalescent model
#'
#' Perform hypothesis test for star tree for a vector of  quartet counts to fit expected frequencies of (1/3,1/3,1/3).
#' The test performed is a standard chi squared.
#'
#' @param obs  vector of 3 counts of resolved quartet frequencies
#' @return p-value
#'
#' @examples
#' obs=c(16,72,12)
#' QuartetStarTest(obs)
#'
#' @export
QuartetStarTest = function(obs) {
  z = chisq.test(obs) #test agaist uniform expectated values
  p = z$p.value
  return(p)
}
