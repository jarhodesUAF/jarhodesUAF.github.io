#' Produce table of counts of quartets displayed on trees
#'
#' Compiles table of counts of topological quartets displayed on a collection of trees.
#' 
#'
#' @details
#' The taxa on the trees may be any set overlapping with \code{taxonnames}.
#' Branch lengths of non-negative size less than or equal to \code{epsilon}
#'  are treated as zero, giving polytomies.
#' 
#' Error if any branch length <0; 
#' Warnings if some of \code{taxonnames} are missing on some trees, or
#' if some 4-taxon set is on no trees.
#'
#' If \code{random}>0, then for efficiency it should be much smaller then
#' the number of possible 4 taxon subsets.
#'
#' @param trees multiphylo object containing un/rooted metric/topological trees
#' @param taxonnames vector of names of taxa of interest, of length \code{n}
#' @param epsilon minimum for branch lengths to be treated as non-zero
#' @param random number of random subsets of 4 taxa to consider; if 0, use all \code{n} choose 4 subsets
#' @return
#'     A (\code{n} choose 4)x(\code{n}+4) matrix (or (\code{random})x(\code{n}+4) matrix) encoding
#'     4 taxon subsets of taxonnames and counts of each of the
#'     quartets 12|34, 13|24, 14|23, 1234 across the trees. Columns are labeled by taxa names and
#'     quartet names("12|34", etc.). 1s and 0s in taxon columns indicate the taxa in quartet.
#'     Quartet 12|34
#'     means first and second indicated taxa form cherry, 13|24 means first and third form cherry, 14|23 means
#'     first and fourth form cherry, and 1234 means unresolved
#' @seealso \code{\link{ResolvedQuartetTable}}, \code{\link{DominantQuartetTable}}
#'
#' @examples
#' gtrees=read.tree(file=system.file("genetreeSample",package="MSCquartets"))
#' taxonnames=AllTaxonNames(gtrees)
#' QT=QuartetTable(taxonnames[1:5],gtrees)
#' RQT=ResolvedQuartetTable(QT)
#' DQT=DominantQuartetTable(RQT)
#'
#' @importFrom ape cophenetic.phylo compute.brlen
#'
#' @export
QuartetTable = function(taxonnames,
                        trees,
                        epsilon = 0,
                        random = 0) {
  if (random < 0)
    stop("Parameter 'random' must be non-negative.")
  random = round(random)
  
  taxonnames = sort(taxonnames) #put taxa in fixed order
  nt = length(trees) # number of gene trees
  N = length(taxonnames) # number of taxa
  if (random > 0)
    M = random # number of 4-taxon sets to consider
  else
    M = choose(N, 4)
  Q = matrix(0, M, N + 4) #allocate space for table
  qnames = c("12|34", "13|24", "14|23", "1234")
  colnames(Q) = c(taxonnames, qnames) #create column names
  warnMissing = 0 # flag for some taxa not on all gene trees
  
  # encode 4-taxon sets in matrix
  if (random == 0) {
    #use all subsets of 4
    m = 0
    for (i in 1:(N - 3)) {
      # for each 4-taxon set
      for (j in (i + 1):(N - 2)) {
        for (k in (j + 1):(N - 1)) {
          for (l in (k + 1):N) {
            m = m + 1
            Q[m, c(i, j, k, l)] = 1 #encode set
          }
        }
      }
    }
  }
  else {
    #use random sets of 4 taxa
    i = 1
    while (i <= random)  {
      q = sample(N, size = 4, replace = FALSE)# 4 random taxa
      row = integer(N) # encode as 0/1 vector
      row[q] = 1
      
      j = 1 #check earlier rows for repeated quartet
      while (j < i) {
        if (identical(Q[j, 1:N], row))
          j = i + 1 #set flag for match
        else
          j = j + 1 # go to next row
      }
      if (j == i) {
        # accept this choice of 4 taxa
        Q[i, 1:N] = row
        i = i + 1
      }
    }
  }
  
  cat(
    paste0(
      'Counting occurrences of displayed quartets for ',
      M,
      ' four-taxon subsets of ',
      N,
      ' taxa across ',
      nt,
      ' gene trees.\n'
    )
  )
  
  for (numt in 1:nt) {
    # for each gene tree
    t = trees[[numt]] #get next tree
    if (is.null(t$edge.length)) {
      t = compute.brlen(t, 1) #if no branch lengths then make them all 1
    } else {
      if (sum(t$edge.length < 0) > 0)
        stop("Error: Negative branch length in tree") #if any negative lengths abort
    }
    
    zeros = which(t$edge.length <= epsilon) # find locations of any zero branch lengths
    t$edge.length[] = 1 # set all lengths to 1, to avoid numerical error in 4-point below
    t$edge.length[zeros] = 0  # reset zeros to 0
    
    d = cophenetic.phylo(t) # get distance matrix for the tree
    for (m in 1:M) {
      # for each 4-taxon set
      tax = as.character(taxonnames[which(Q[m, 1:N] == 1)]) # names of 4 taxa (or fewer)
      if (all(tax %in% colnames(d))) {
        # if all 4 taxa present on this tree
        a = d[tax[1], tax[2]] + d[tax[3], tax[4]] # use 4-point condition
        b = d[tax[1], tax[3]] + d[tax[2], tax[4]]  #    to determine quartet
        c = d[tax[1], tax[4]] + d[tax[2], tax[3]]  #
        z = sort(c(a, b, c))
        if (z[1] == z[2]) {
          # tie means a polytomy
          Q[m, "1234"] = Q[m, "1234"] + 1
        } else {
          if (z[1] == a) {
            #quartet is ab|cd
            Q[m, "12|34"] = Q[m, "12|34"] + 1
          } else {
            if (z[1] == b) {
              #quartet is ac|bd
              Q[m, "13|24"] = Q[m, "13|24"] + 1
            } else {
              Q[m, "14|23"] = Q[m, "14|23"] + 1
            } #quartet is ad|bc
          }
        }
      } else
        warnMissing = 1 # some taxa not on this tree
    }
  }
  
  if (warnMissing == 1)
    warning("Some taxa missing from some trees.")
  if ((N > 4) && (sum(rowSums(Q[, qnames, drop = FALSE]) == 0) > 0))
    warning("Some 4-taxon set not present on any tree.")
  if (sum(Q[, "1234"]) > 0)
    warning("Some quartets unresolved.")
  
  return(Q)
}

#################################################

#' Modify table of counts of quartets to only show resolved ones
#'
#' Converts table of all quartet counts, including unresolved ones, 
#' by either dropping unresolved ones, or distributing them uniformly 
#' among resolved counts.
#'
#' @param QT table as produced by \code{QuartetTable} of size (n choose 4)x(n+4)
#' @param omit TRUE deletes unresolved quartets column;
#'            FALSE redistributes unresolved counts as (1/3,1/3,1/3) to resolved counts
#' @return
#'      A table of size (n choose 4)x(n+3), similar to QuartetTable
#'
#' @examples
#' gtrees=read.tree(file=system.file("genetreeSample",package="MSCquartets"))
#' taxonnames=AllTaxonNames(gtrees)
#' QT=QuartetTable(taxonnames[1:5],gtrees)
#' RQT=ResolvedQuartetTable(QT)
#' DQT=DominantQuartetTable(RQT)
#'
#' @seealso \code{\link{QuartetTable}}, \code{\link{DominantQuartetTable}}
#' @export
ResolvedQuartetTable = function(QT, omit = FALSE) {
  RT = QT[,-which(colnames(QT) == "1234"), drop = FALSE]  #copy table without unresolved column
  if (omit == FALSE) {
    qs = c("12|34", "13|24", "14|23") #columns to be adjusted
    RT[, qs] = RT[, qs, drop = FALSE] + QT[, "1234", drop = FALSE] %*% matrix(1 / 3, 1, 3) #redistribute counts
  }
  return(RT)
}

#################################################


#' Produce table of dominant quartets, with ML estimates of internal edge length under the MSC model
#'
#' Converts table of counts of resolved quartets on \code{n} taxa to show only dominant one, with
#' maximum likelihood estimate of internal edge weight under the multispecies
#' coalescent model.
#'
#' @param RQT array as produced by \code{ResolvedQuartetTable} of size (n choose 4)x(n+3);
#' @param bigweights "infinite" or "finite", determines if the weight of a quartet for which only one
#' topology appears is given as "Inf" or a finite, but large, numerical value
#' 
#' @return
#'   An (n choose 4)x(n+1) array with dominant quartet topology encoded by 1,1,-1,-1 in
#' taxon columns, with signs indicating cherries. Column "weight" contains ML estimate
#' under MSC model of quartets central edge length, in coalescent units.
#'
#' @examples
#' gtrees=read.tree(file=system.file("genetreeSample",package="MSCquartets"))
#' taxonnames=AllTaxonNames(gtrees)
#' QT=QuartetTable(taxonnames[1:5],gtrees)
#' RQT=ResolvedQuartetTable(QT)
#' DQT=DominantQuartetTable(RQT)
#'
#' @seealso \code{\link{QuartetTable}}, \code{\link{ResolvedQuartetTable}}
#' @importFrom stats runif
#' @export
DominantQuartetTable = function(RQT, bigweights="infinite") {
  M = dim(RQT)[1] # number of 4-taxon sets
  N = dim(RQT)[2] - 3 # number of taxa
  taxonnames = colnames(RQT)[1:N] # names of taxa
  
  DQT = RQT[, 1:(N + 1)] # allocate space for most frequent quartet topologies and weight
  for (m in 1:M) {
    # for each 4-taxon set
    taxa = which(RQT[m, 1:N] == 1) # taxa numbers
    z = RQT[m, (N + 1):(N + 3)] # frequencies of quartets
    tz = sum(z) # total number of quartets
    if (tz > 0) {
      # if some quartets were found
      mq = which.max(z + runif(3)) # which is biggest? (random tie-breaking)
      if (mq == 1) {
        DQT[m, c(taxa[3], taxa[4])] = -1
      } else {
        if (mq == 2) {
          DQT[m, c(taxa[2], taxa[4])] = -1
        } else {
          DQT[m, c(taxa[2], taxa[3])] = -1
        }
      }
      f = z[mq] / tz #relative frequency of most frequent quartet
      if (f<1) { # if some ILS
        DQT[m, N + 1] = -log((1.5 * (1 - f))) # save weight
      } else { # if no ILS
      if (bigweights =="infinite"){
        DQT[m, N + 1] = Inf
      } else { #despite no ILS give finite weight
      f = 1- .5/tz # pretend f is a bit less than 1
      DQT[m, N + 1] = -log((1.5 * (1 - f))) # save weight
    }
  }
  
    }
  }
  colnames(DQT) = c(taxonnames, "weight") #add column names
  return(DQT)
}

######################################################################################

#' Get all taxon names from a collection of trees
#'
#' Create a list of all taxa names appearing on a collection of trees, with no repeats.
#'
#' @param trees a multiphylo object containing a collection of trees
#'
#' @return a vector of unique names of taxa appearing on the trees
#'
#' @examples
#' gtrees=read.tree(file=system.file("genetreeSample",package="MSCquartets"))
#' taxonnames=AllTaxonNames(gtrees)
#'
#' @export
AllTaxonNames = function(trees) {
  taxa = c()
  for (i in 1:length(trees)) {
    taxa = union(taxa, trees[[1]]$tip.label)
  }
  return(taxa)
}