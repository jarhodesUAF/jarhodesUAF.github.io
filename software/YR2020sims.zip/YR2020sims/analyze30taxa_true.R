# R script to apply various species tree inference methods to simulated data, as shown in (Yourdkhani & Rhodes, 2020).
# This file processes the 'true' gene trees sampled from the MSC.
#
# Before running: 
# 1) The simulated avian data of Bayzid, Mirarab, Boussau, & Warnow (2014) must be downloaded. 
#    The data directories listed below in the variable 'sims' should be placed in the current directory.
#    The download website is currently: https://sites.google.com/eng.ucsd.edu/datasets/binning
# 2) The MSCquartets R package must be installed.
# 3) ASTRAL must be installed, and its call in the code below possibly modified depending on its location.


sims = c("./0.5X-1000-true","./1X-1000-true","./2X-1000-true")
samplesizes = c(100,400,700,1000) # number of genes

outputfile = "./output"

tree = read.tree("./avian-model-species.tre") #get species tree
drops = 28:45 #taxa to drop so only 30 remain
droptaxa = tree$tip.label[drops]
tree = drop.tip(tree, droptaxa)
tree = unroot(tree)
taxanames = tree$tip.label
ntaxa = length(taxanames)

#create list of scaled species trees, with pendant and long edges modified for comparison to inferred trees
tree05=tree
tree05$edge.length=0.5*tree05$edge.length
tree05$edge.length[which(tree05$edge[,2]<=ntaxa)]=1 #set pendant lengths to 1
tree05$edge.length[which(tree05$edge.length>2)]=2 #set long lengths to 2
tree1=tree
tree1$edge.length[which(tree1$edge[,2]<=ntaxa)]=1 #set pendant lengths to 1
tree1$edge.length[which(tree1$edge.length>2)]=2 #set long lengths to 2  
tree2=tree
tree2$edge.length=2*tree2$edge.length
tree2$edge.length[which(tree2$edge[,2]<=ntaxa)]=1 #set pendant lengths to 1
tree2$edge.length[which(tree2$edge.length>2)]=2 #set long lengths to 2
strees=c(tree05,tree1,tree2)



numedges = 2 * ntaxa - 3
ones = rep(1, numedges)
ntp1 = ntaxa + 1
ntp4 = ntaxa + 4

nsims = length(sims)
diffsizes = diff(samplesizes)
nssizes = length(samplesizes)

#create matrices for storing results
Summary= matrix(0, 2 * nsims, nssizes)# space for stats
colnames(Summary) = samplesizes
simssd = paste0(sims, "_sd")
rownames(Summary) = c(sims, simssd)
metricSummaryQDCnjfit = Summary
metricSummaryWQDCfm = Summary
metricSummaryWQDCnj = Summary
metricSummaryWQDCrec0fm = Summary
metricSummaryWQDCrec2fm = Summary
metricSummaryASTRAL=Summary
topSummaryQDCnjfit = Summary
topSummaryWQDCfm = Summary
topSummaryWQDCnj = Summary
topSummaryWQDCrec0fm = Summary
topSummaryWQDCrec2fm = Summary
topSummaryASTRAL=Summary

simnum = 0
for (sim in sims)
{
  simnum = simnum + 1
  print(sim)
  sptree=strees[simnum]
  
  replicates = list.files(sim)
  nreps = length(replicates)
  
  metricWQDCfmscores = matrix(0, nreps, nssizes)
  metricASTRALscores = matrix(0, nreps, nssizes)
  metricWQDCnjscores = matrix(0, nreps, nssizes)
  metricWQDCrec0fmscores = matrix(0, nreps, nssizes)
  metricWQDCrec2fmscores = matrix(0, nreps, nssizes)
  metricQDCnjfitscores = matrix(0, nreps, nssizes)
  
  topWQDCfmscores = matrix(0, nreps, nssizes)
  topASTRALscores = matrix(0, nreps, nssizes)
  topWQDCnjscores = matrix(0, nreps, nssizes)
  topWQDCrec0fmscores = matrix(0, nreps, nssizes)
  topWQDCrec2fmscores = matrix(0, nreps, nssizes)
  topQDCnjfitscores = matrix(0, nreps, nssizes)
  
  repnum = 0
  for (r in replicates)
  {
    repnum = repnum + 1
    print(r)
    genets = list.files(paste0(sim, "/", r))
    ngts = length(genets)
    genetrees = rmtree(ngts, 2)# create multiphylo object for storing gene trees
    t = 0
    for (genet in genets)
      #read in all gene trees
    {
      t = t + 1
      gtfile = paste0(sim,
                      "/",
                      r,
                      "/",
                      genet,
                      "/true.gt")
      genetrees[[t]] = drop.tip(read.tree(gtfile), droptaxa) # read tree and reduce to 30 or fewer taxa
    }
    
    samplesizenum = 0
    for (s in samplesizes)
      # for all sample sizes compute all species trees
    {
      samplesizenum = samplesizenum + 1
      print(paste("samplesize:", s))
      subsetgenetrees=genetrees[1:s]
      if (samplesizenum == 1) {
        Q = quartetTable(subsetgenetrees,taxanames) # use first group of gene trees
      }
      else {
        start = s - diffsizes[samplesizenum - 1] + 1 # take a later group of gene trees
        newQ = quartetTable(subsetgenetrees[start:s],taxanames) # tabulate quartets for them
        Q[, ntp1:ntp4] = Q[, ntp1:ntp4] + newQ[, ntp1:ntp4]#       and add to earlier tabulation
      }
     
      RQ = quartetTableResolved(Q)
      DQ = quartetTableDominant(RQ,bigweights="finite")
      
      #ASTRAL
      { write.tree(subsetgenetrees, file="tempgts")
        system(" java -jar ASTRAL/astral.5.6.3.jar -i tempgts -o astralST 2>astral.log")
        astralST=unroot(read.tree(file="astralST"))
        astralST$edge.length[which(astralST$edge[,2]<=ntaxa)]=1 #set pendant lengths to 1
        astralST$edge.length[which(astralST$edge.length>2)]=2 #set long lengths to 2
        
        rf = dist.topo(sptree,astralST,method="score") # compute  distance between trees using branch length
        metricASTRALscores[repnum, samplesizenum] = rf
        rf = dist.topo(sptree,astralST) # compute toplogical distance between trees
        topASTRALscores[repnum, samplesizenum] = rf
      }
      
      #QDC+NJ
      {qdst = unroot(QDC(RQ,method=nj)) # performs QDC, returning unrooted output tree in phylo format
        qdst=estimateEdgeLengths(qdst,RQ) # estimate branch lengths
        qdst$edge.length[which(qdst$edge[,2]<=ntaxa)]=1 #set pendant lengths to 1
        qdst$edge.length[which(qdst$edge.length>2)]=2 #set long lengths to 2
        
        rf = dist.topo(sptree, qdst,method="score") # compute  distance between trees using branch length
        metricQDCnjfitscores[repnum, samplesizenum] = rf
        rf = dist.topo(sptree, qdst) # computetopological distance between trees 
        topQDCnjfitscores[repnum, samplesizenum] = rf
      }
      
      
      #WQDCrecursive, stopping at edge length 0
      {wqdst = unroot(WQDCrecursive(RQ,stopAt = 0)) # performs Recursive WQDS, returning unrooted output tree in phylo format
        wqdst$edge.length[which(wqdst$edge[,2]<=ntaxa)]=1 #set pendant lengths to 1
        wqdst$edge.length[which(wqdst$edge.length>2)]=2 #set long lengths to 2

        rf = dist.topo(sptree, wqdst,method="score") # compute  distance between trees using branch length
        metricWQDCrec0fmscores[repnum, samplesizenum] = rf
        rf = dist.topo(sptree, wqdst) # compute topological distance between trees
        topWQDCrec0fmscores[repnum, samplesizenum] = rf
      }

      #WQDCrecursive, stopping at edge length 2
      {wqdst = unroot(WQDCrecursive(RQ,stopAt = 2)) # performs Recursive WQDS, returning unrooted output tree in phylo format
        wqdst$edge.length[which(wqdst$edge[,2]<=ntaxa)]=1 #set pendant lengths to 1
        wqdst$edge.length[which(wqdst$edge.length>2)]=2 #set long lengths to 2

        rf = dist.topo(sptree, wqdst,method="score") # computedistance between trees using branch length
        metricWQDCrec2fmscores[repnum, samplesizenum] = rf
        rf = dist.topo(sptree, wqdst) # compute topological distance between trees
        topWQDCrec2fmscores[repnum, samplesizenum] = rf
      }

      #WQDC+fastME
      {wqdst = unroot(WQDS(DQ,method=fastme.bal)) # performs WQDS, returning unrooted output tree in phylo format
        wqdst$edge.length[which(wqdst$edge[,2]<=ntaxa)]=1 #set pendant lengths to 1
        wqdst$edge.length[which(wqdst$edge.length>2)]=2 #set long lengths to 2

        rf = dist.topo(sptree, wqdst,method="score") # compute  distance between trees using branch length
        metricWQDCfmscores[repnum, samplesizenum] = rf
        rf = dist.topo(sptree, wqdst) # compute topological distance between trees
        topWQDCfmscores[repnum, samplesizenum] = rf
      }

      #WQDC+NJ
      {wqdst = unroot(WQDS(DQ, method = nj)) # performs WQDS, returning unrooted output tree in phylo format
        wqdst$edge.length[which(wqdst$edge[,2]<=ntaxa)]=1 #set pendant lengths to 1
        wqdst$edge.length[which(wqdst$edge.length>2)]=2 #set long lengths to 3

        rf = dist.topo(sptree, wqdst,method="score") # compute  distance between trees using branch length
        metricWQDCnjscores[repnum, samplesizenum] = rf
        rf = dist.topo(sptree, wqdst) # compute  topological distance between trees
        topWQDCnjscores[repnum, samplesizenum] = rf
      }
    }
  }
  
  metricSummaryWQDCrec0fm[simnum, ] = colMeans(metricWQDCrec0fmscores)
  metricSummaryWQDCrec0fm[simnum + nsims, ] = apply(metricWQDCrec0fmscores, 2, sd)
  
  metricSummaryWQDCrec2fm[simnum, ] = colMeans(metricWQDCrec2fmscores)
  metricSummaryWQDCrec2fm[simnum + nsims, ] = apply(metricWQDCrec2fmscores, 2, sd)
  
  metricSummaryWQDCfm[simnum, ] = colMeans(metricWQDCfmscores)
  metricSummaryWQDCfm[simnum + nsims, ] = apply(metricWQDCfmscores, 2, sd)
  
  metricSummaryWQDCnj[simnum, ] = colMeans(metricWQDCnjscores)
  metricSummaryWQDCnj[simnum + nsims, ] = apply(metricWQDCnjscores, 2, sd)
  
  metricSummaryQDCnjfit[simnum, ] = colMeans(metricQDCnjfitscores)
  metricSummaryQDCnjfit[simnum + nsims, ] = apply(metricQDCnjfitscores, 2, sd)
  
  metricSummaryASTRAL[simnum, ] = colMeans(metricASTRALscores)
  metricSummaryASTRAL[simnum + nsims, ] = apply(metricASTRALscores, 2, sd)
  
  
  
  topSummaryWQDCrec0fm[simnum, ] = colMeans(topWQDCrec0fmscores)
  topSummaryWQDCrec0fm[simnum + nsims, ] = apply(topWQDCrec0fmscores, 2, sd)
  
  topSummaryWQDCrec2fm[simnum, ] = colMeans(topWQDCrec2fmscores)
  topSummaryWQDCrec2fm[simnum + nsims, ] = apply(topWQDCrec2fmscores, 2, sd)
  
  topSummaryWQDCfm[simnum, ] = colMeans(topWQDCfmscores)
  topSummaryWQDCfm[simnum + nsims, ] = apply(topWQDCfmscores, 2, sd)
  
  topSummaryWQDCnj[simnum, ] = colMeans(topWQDCnjscores)
  topSummaryWQDCnj[simnum + nsims, ] = apply(topWQDCnjscores, 2, sd)
  
  topSummaryQDCnjfit[simnum, ] = colMeans(topQDCnjfitscores)
  topSummaryQDCnjfit[simnum + nsims, ] = apply(topQDCnjfitscores, 2, sd)
  
  topSummaryASTRAL[simnum, ] = colMeans(topASTRALscores)
  topSummaryASTRAL[simnum + nsims, ] = apply(topASTRALscores, 2, sd)
}

p="_"
write.table(metricSummaryWQDCrec0fm, paste0(outputfile, "metricTrue", p, "WQDCrec0fm"))
write.table(metricSummaryWQDCrec2fm, paste0(outputfile, "metricTrue", p, "WQDCrec2fm"))
write.table(metricSummaryWQDCfm, paste0(outputfile, "metricTrue", p, "WQDCfm"))
write.table(metricSummaryWQDCnj, paste0(outputfile, "metricTrue", p, "WQDCnj"))
write.table(metricSummaryQDCnjfit, paste0(outputfile, "metricTrue", p, "QDCnjfit"))
write.table(metricSummaryASTRAL, paste0(outputfile, "metricTrue", p, "ASTRAL"))

write.table(topSummaryWQDCrec0fm, paste0(outputfile, "topTrue", p, "WQDCrec0fm"))
write.table(topSummaryWQDCrec2fm, paste0(outputfile, "topTrue", p, "WQDCrec2fm"))
write.table(topSummaryWQDCfm, paste0(outputfile, "topTrue", p, "WQDCfm"))
write.table(topSummaryWQDCnj, paste0(outputfile, "topTrue", p, "WQDCnj"))
write.table(topSummaryQDCnjfit, paste0(outputfile, "topTrue", p, "QDCnjfit"))
write.table(topSummaryASTRAL, paste0(outputfile, "topTrue", p, "ASTRAL"))

