#' Plot histogram of log base 10 of p-values in table
#'
#' Graphical exploration of extreme p-values from quartet hypothesis tests, to aid in choosing critical values
#' for use in NANUQ algorithm
#' 
#'@param pTable a table of quartet p-values such as from \code{MultiIndepQuartetTreeTest} 
#'       or from \code{MultiIndepQuartetStarTest}
#'@param pcol  name of column of pTable containing p-values, "p_T1","p_T3", or "p_star"
#'@param pmin omit all p-values below \code{pmin}
#'
#'@examples
#' pTable=NANUQf(system.file("yeastRokas",package="MSCquartet"), alpha=0, beta=.95)
#' log10Hist(pTable,"p_T3")
#' NANUQdist(pTable, alpha=10^-5, beta=.95)
#' NANUQdist(pTable, alpha=10^-3, beta=.95)
        
#'
#'@export
log10Hist = function(pTable, pcol, pmin = 0) {
  pvals = pTable[, pcol]
  vals = pvals[which(pvals >= pmin)]
  par(mar=c(5.1,4.1,4.1,2.1))# set margin
  hist(log10(vals),
       main = bquote("Histogram of log"[10]*"("*.(pcol)*"), "*.(pcol)>.(pmin)))
}
