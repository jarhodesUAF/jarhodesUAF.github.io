#' Compute the Recursive Weighted Quartet Distance Consensus tree from gene tree data
#' 
#' Infer a metric species tree from counts 
#' of quartets displayed on a collection of gene trees, as described in [YR2019]. 
#' 
#' 
#' @details The algorithm counts quarets displayed on the gene trees, builds a tree using WQDS,
#' determines the split corrsponding to the longest edge in that tree, 
#' and then recursively builds trees 
#' on the taxa in each split set together with a 'composite taxon' formed by all 
#' taxa in the other split set.
#' This approach is slower the WQDS, but increases topological accuracy.
#' 
#' This function must be called with its argument a resolved quartet 
#' table (not a dominant quartet table) of size (n choose 4)x(n+3). Its recursive nature 
#' requires building smaller resolved quartet tables on split sets with an additional 
#' composite taxon.
#' 
#' @param rqt a resolved quartet table as produced by \code{quartetTableResolved}
#' @param terminal non-negative branch length to supply for terminal branches, 
#' whose length cannot be inferred by WQDCrecursive
#' 
#' @return an unrooted metric tree, of type "phylo"
#' 
#' @seealso \code{\link{quartetTableResolved}},\code{\link{quartetTable}},
#' \code{\link{QDC}}, \code{\link{QDS}}, \code{\link{quartetTableCollapse}}
#' 
#' @examples 
#' gtrees=read.tree(file=system.file("extdata","dataGeneTreeSample",package="MSCquartets"))
#' taxanames=taxonNames(gtrees)
#' QT=quartetTable(gtrees,taxanames[1:5])
#' RQT=quartetTableResolved(QT)
#' stree=WQDCrecursive(RQT)
#' plot(stree)
#' stree
#' 
#' @importFrom ape Ntip drop.tip bind.tree
#' 
#' @export
WQDCrecursive = function(rqt, terminal=1) {
  
  nX = dim(rqt)[2] - 3 # number of taxa
  if (nX<4) {
    stop("Fewer than 4 taxa.")
  }
  
  taxanames = colnames(rqt)[1:nX]# get taxa names
  DQT=quartetTableDominant(rqt,bigweights = "finite")
  roughtree <- root(WQDS(DQT),taxanames[1])# construct initial estimate of tree, with arbitrary root
  internaledgeindices=which(roughtree$edge[,2] > Ntip(roughtree)) # determine internal edges
  
  length=max(roughtree$edge.length[internaledgeindices]) #get longest internal edge length, 
  longestedges=which(roughtree$edge.length[internaledgeindices]==length)# and logest edges
  if (is.vector(longestedges)){
  longestedge=sample(longestedges,1)# random tie breaking
  } else {
    longestedge=longestedges
  }
  longestinternaledgeindex=internaledgeindices[longestedge]# ...to pick edge
  
  node = roughtree$edge[longestinternaledgeindex, 2] # get child of edge
  taxaAind = phangorn::Descendants(roughtree, node, "tips")[[1]] # determine split sets for that edge 
  taxaA=roughtree$tip.label[taxaAind]
  nA=length(taxaAind)
  taxaB = setdiff(taxanames, taxaA)
  nB=nX-nA
  length=length/((nA-1)*(nB-1))
  
  if (nA>2) { # at least 3 taxa in A
    RQTA = quartetTableCollapse(rqt, taxaA, taxaB) #create smaller tables for set A \cup {"setB"} 
    ##RQTA<<-RQTA
    Ap1tree = WQDCrecursive(RQTA) #recursively build tree
    #print("A>2")
    Bname=paste0(sort(taxaB),collapse="")
    #print(c("Ap1:",Ap1tree$tip.label))
    #print(c("Ap1tree",write.tree(Ap1tree)))
    Atree = drop.tip(root(Ap1tree, Bname, resolve.root = TRUE), Bname)
  } else { # only 2 taxa in A
    #print("A=2")
    Atree =drop.tip(root(roughtree,taxaB[1],resolve.root=TRUE),taxaB) #keep only cherry for A
  }
  
  if (nB>2) { # at least 3 taxa in B
    RQTB = quartetTableCollapse(rqt, taxaB, taxaA) #create smaller tables for set B \cup {"setA"} 
    #print(RQTB)
    Bp1tree = WQDCrecursive(RQTB) #recursively build tree
    #print("B>2")
    #print(c("Bp1tree",write.tree(Bp1tree)))
    Aname=paste0(sort(taxaA),collapse="")
    Btree = drop.tip(root(Bp1tree, Aname, resolve.root = TRUE), Aname)
  } else { # only 2 taxa in B
    #print("B=2")
    Btree =drop.tip(root(roughtree,taxaA[1],resolve.root=TRUE),taxaA) #keep only cherry for A
  }
  
  Atree$root.edge=length
  #print(RQT)
  #print(DQT)
  #print(c("roughtree:",write.tree(roughtree)))
  #print(c("A:",taxaA))
  #print(c("B:",taxaB))
 #print(c("call",lcall,"Atree",write.tree(Atree)))
 #print(c("call",lcall,"Btree",write.tree(Btree)))
  Xtree = unroot(bind.tree(Atree, Btree, position=length))
  
  term_edges = which(Xtree$edge[, 2] <= length(taxanames)) #modify terminal edge lengths
  Xtree$edge.length[term_edges] = terminal
  
  #plot(Xtree, "unrooted")
  #print(c("call",lcall,"Xtree",write.tree(Xtree)))
  return(Xtree)
}



#' Form a smaller resolved quartet table by lumping some taxa into a composite taxon
#'
#' @details This function is needed for the recursive calls in \code{WQDSrec}.
#' It should only be applied to a resolved quartet table which includes counts 
#' for all possible quartets on the taxa (though counts can be zero).
#' 
#' @param rqt a resolved quartet table, as from \code{quartetTableResolved}
#' @param taxaA a vector of taxon names in \code{rqt} to be included in new table
#' @param taxaB a vector of taxon names in \code{rqt} to form new composite taxon in new table
#' 
#' @return a resolved quartet table with \code{length(taxaA)+1} taxa. The 
#'  composite taxon is named as the concatenation of the sorted 
#'  names in \code{taxaB}
#'  
#' @seealso \code{\link{WQDCrecursive}}
#'  
#' @export
quartetTableCollapse = function(rqt, taxaA, taxaB) {
  
  taxaAB=union(taxaA,taxaB)
  if (!setequal( intersect(taxaAB,colnames(rqt)), taxaAB)){
    stop("Not all taxa in given sets in table.")
  } else {
    if (length(intersect(taxaA,taxaB))!=0)
      stop("Given taxon sets must be disjoont.")
  }
  
  
  M = dim(rqt)[1]
  ntaxa=dim(rqt)[2]-3
  coltaxa=colnames(rqt)[1:ntaxa]
  nA = length(taxaA)
  nB = length(taxaB)
  taxaA=coltaxa[sort(match(taxaA,coltaxa))] #order taxa A as in rqt
  
  #print(c(dim(rqt)[2],nA,nB))
  
  #set up table for subset A + "setB"
  nAp1 = nA + 1 
  mRQTA = choose(nAp1, 4)
  RQTA = matrix(0, mRQTA, nAp1 + 3) 
  qnames = c("12|34", "13|24", "14|23")
  Bname = paste0(sort(taxaB),collapse="") #create name for composite taxon for set B
  colnames(RQTA) = c(taxaA, Bname, qnames) #create column names
  
  # encode 4-taxon sets in table
  m = 0 
  for (i in 1:(nAp1 - 3)) { # for each 4-taxon set
    for (j in (i + 1):(nAp1 - 2)) {
      for (k in (j + 1):(nAp1 - 1)) {
        for (l in (k + 1):nAp1) {
          m = m + 1
          RQTA[m, c(i, j, k, l)] = 1 #encode set
        }
      }
    }
  }
  
  # fill counts in new table, by running through old table
  for (m in 1:M) {
    
    memA = taxaA[which(rqt[m, taxaA]==1)]
    numA = length(memA)
    
    if (numA == 4) {
      mA = which(rowSums(RQTA[,memA,drop=FALSE]) == 4)
      RQTA[mA, qnames] = rqt[m, qnames]
    } else {
      if (numA == 3)  {
        mA=which(rowSums(RQTA[,c(memA,Bname),drop=FALSE]) == 4 )
        taxonB=which(is.element(coltaxa[which(rqt[m,coltaxa]==1)],taxaB))
        z=rqt[m,qnames]
        if (taxonB==1) {
          RQTA[mA, qnames] = RQTA[mA, qnames] + z[c(3,2,1)]
        } else{
          if (taxonB==2){
            RQTA[mA, qnames] = RQTA[mA, qnames] + z[c(2,3,1)]
          } else{
            if (taxonB==3){
              RQTA[mA, qnames] = RQTA[mA, qnames] + z[c(1,3,2)]
            }else{
              RQTA[mA, qnames] = RQTA[mA, qnames] + z
            }
          }
        }
      }
    }
  }
return(RQTA)
}


