#' Multispieces Coalescent Model Quartet Package
#'
#' A package for analyzing quartets displayed on gene trees, under the multispecies coalscent (MSC) model.
#'
#' @details
#' This package contains routines to analyze a collection of gene trees through the displayed 
#' quartets on them.
#' 
#' Recall a quartet count concordance factor (QCCF) for a set of 4 taxa is the triple of counts of the three
#' possible resolved quartet trees on those taxa. The major routines in this package can:
#' \enumerate{
#' \item Tabulate all QCCFs for a collection of gene trees
#' \item Perform hypothesis tests of whether one or more QCCFs are consistent with the MSC model on
#' a species tree, as in [MAR19]
#' \item Infer a species tree using the QCCFs via the methods of [R19] and [YR19]
#' \item Infer a level-1 species network via the NANUQ method of [ABR19]
#' }
#'As discussed in the cited works, the inference methods for species trees and networks are
#'statistically consistent under the MSC and Network MSC respectively.
#'
#' Two data sets are included as text files. The file "genetreeSample" contains a sample of 10000 gene trees
#'  sampled under the MSC from the species tree \code{((a,b),(c,(d,e)));}. The file "yeastRokas" contains
#'  106 gene trees for 7 yeast and one outgroup, subtrees of the Rokas 2003 data set.
#'   
#' @references
#'
#' [R19] \emph{Toplogical metrizations of trees and new quartet methods of tree inference,} J.A. Rhodes,
#' IEEE/ACM Trans. Comput. Biol. Bioinf., early access, 2019
#'
#' [MAR19] \emph{Hypothesis testing near singularities and bondaries,} J.D. Mitchell, E.S. Allman, J.A. Rhodes, Electron. J. Statist., 13 (1)  2019
#'
#' [YR19] \emph{Metrizing trees with weighted quartets, and species tree inference,} S. Yourdkhani, J.A. Rhodes, ??draft??, 2019
#'
#' [ABR19] \emph{NANUQ: A method for inferring species networks from gene trees under the coalescent model,}, E.S. Allman, H. Banos, J.A. Rhodes, 
#' submitted, 2019
#' 
#' @importFrom graphics hist legend mtext par plot points segments text
#' @importFrom stats chisq.test dmultinom pchisq qnorm
#'
#' @docType package
#' @name MSCquartets
NULL

