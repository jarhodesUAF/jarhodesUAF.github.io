#' Functions to test whether simulators
#' of the multspecies coalsecent model in phylogenomics give valid gene tree samples.
#'
#' The package performs comparisons of certain summary statistics for simulated gene tree samples to
#' theoretical predictions under the multspecies coalsecent model.
#' The primary functions are \code{rootedTriple} for comparison of frequencies of topological rooted triples on gene trees, and
#' the pair \code{pairwiseDist} and \code{ADtest} for comparison of the distribution of distances between taxa on
#' gene trees.
#'
#' \code{MSCsimtester} builds on the packages \code{ape} and \code{kSample}.
#'
#' Required input is a collection of gene trees, stored as a \code{multiPhylo} object by the \code{ape} package, and a specification of a rooted species tree
#' with edge lengths in generations, together with population sizes for each edge.
#'
#' For further examples of use and citation purposes, see H. Banos, E.S. Allman, and J.A. Rhodes,
#' 'Testing Multispecies Coalescent Simulators Using Summary Statistics,' 2019.
#'
#' @docType package
#' @name MSCsimtester
NULL


#' Plot species tree, with edge numbers on edges.
#'
#' Under the MSC, each edge in the species tree must be assigned a population
#' size.  This function displays the species tree with the edges
#' numbered, to aid the user in entering constant population sizes as an
#' appropriately ordered list.
#'
#' @param stree An object of class \code{phylo} containing a rooted metric
#' species tree.
#' @examples stree=read.tree(text="(((a:10000,b:10000):10000,c:20000):10000,d:30000);")
#' edgeOrder(stree)
#' pops=c(30000,20000,1,1,1,1,10000)
#' plotPops(stree,pops)
#'
#' @seealso \code{\link{pairwiseDist}}, \code{\link{rootedTriple}}, \code{\link{plotPops}}
#'
#' @return NULL
#'
#' @export
edgeOrder = function(stree)
  {
  if (is.rooted(stree)==FALSE) {stop("Tree should be rooted.")}
  plot.phylo(stree, label.offset = 1, cex=1.3, edge.width=3, main="Edge Order")
  numEdges=dim(stree$edge)[1]
  edgeNumbers=c(1:numEdges)
  edgelabels(edgeNumbers, srt = 0, bg="white", cex=1.3)
  print(paste0("The population above the root should be the last entry (i.e. number ",numEdges+1,") in the population vector."))
}

#' Plot species tree, with population sizes on edges.
#'
#' @param stree An object of class \code{phylo} containing a rooted metric species tree.
#' @param populations A vector of type numeric containing the population sizes for the
#' edges, with last entry the population ancestral to the root.
#'
#' @return NULL
#'
#' @examples stree=read.tree(text="(((a:10000,b:10000):10000,c:20000):10000,d:30000);")
#' edgeOrder(stree)
#' pops=c(30000,20000,1,1,1,1,10000)
#' plotPops(stree,pops)
#'
#' @seealso \code{\link{pairwiseDist}}, \code{\link{rootedTriple}}, \code{\link{edgeOrder}}
#'
#' @export
plotPops = function(stree,populations)
{
  if (is.rooted(stree)==FALSE) {stop("Tree should be rooted.")}
  len=length(populations)
  if (dim(stree$edge)[1]!=len-1) {stop("Number of population sizes is incorrect.")}
  rootPop=populations[len]
  populations=populations[1:len-1]
  plot.phylo(stree, label.offset = 1, cex=1.3, edge.width=1.3, main="Population Sizes")
  edgelabels(populations, srt = 0, bg="white", cex=1.5, col="deepskyblue2")
  print(paste0("Root population has size ",rootPop))
}





#' Compute and plot pairwise distance densities.
#'
#' Computes theoretical pairwise distance densities under the MSC and empirical pairwise distances from
#' the gene trees in a sample. A histogram of empirical values is plotted over the theoretical pdf.
#'
#' @details
#' \code{numSteps} equally spaced points will be sampled for creating
#' the theoretical pairwise distance density.  Default is \code{numSteps = 1000}.
#'
#' @param stree An object of class \code{phylo} containing a metric species tree. Edge lengths are in
#' number of generations.
#' @param popSizes An ordered list containing constant population sizes, one entry for each
#' population in the species tree, for a haploid population.  Sizes should be doubled for diploids.
#' If \code{stree} has k edges, then \code{popSizes} must have k+1 elements, with final entry
#' for the population ancestral to the root.
#' @param gtSample An object of class \code{multiPhylo} holding a sample of gene trees from a simulation.
#' Taxon labels on gene trees must be identical to those on \code{stree}.
#' @param taxon1 A string specifying one taxon on \code{stree}.
#' @param taxon2 A string specifying a second taxon on \code{stree}, distinct
#' from \code{taxon1}.
#' @param numSteps A positive integer giving the number of values on the x-axis to be sampled for creating
#' and graphing the theoretical pairwise distance density.  Default is \code{numSteps = 1000}.
#' Increasing this value will smooth the plot of the theoretical pairwise distance density.
#' @param tailProb The theoretical pairwise distance will be plotted from (0, xMax).  The maximum
#' value xMax is either the maximum pairwise distance in the gene tree sample or the x-value subtending a
#' probability of \code{tailProb} under the pdf.  Default is .01.
#'
#'
#' @return A list of items needed for use in Anderson-Darling test(s), for use by \code{ADtest}. See function code for more details.
#'
#' @examples stree=read.tree(text="((((a:10000,b:10000):10000,c:20000):10000,d:30000):10000,e:40000);")
#' pops=c(15000,25000,10000,1,1,1,1,1,12000)
#' gts=read.tree(file=system.file("genetreeSample",package="MSCsimtester"))
#' pairwiseDist(stree,pops,gts,"a","b")
#'
#' @seealso \code{\link{edgeOrder}}, \code{\link{plotPops}}, \code{\link{ADtest}}
#'
#' @export
#'
pairwiseDist = function(stree,popSizes,gtSample,taxon1,taxon2,numSteps=1000,tailProb=.01)
{
  #subfunction definitions
  checkTipLabels = function(stree,gtree)
  {
    tipsSpeciesTree=stree$tip.label
    tipsGeneTree=gtree$tip.label
    sameTips=setequal(tipsGeneTree,tipsSpeciesTree)
    return(sameTips)
  }

  # some initial (limited) checks

  if (identical(taxon1,taxon2)) {
    warning('Taxa must be different. Exiting.')
    return(invisible())
  }

  # Check that the tip labels in species tree and the first gene tree agree.
  if (checkTipLabels(stree,gtSample[[1]])==FALSE) {
    warning('Tip labels on species tree and gene tree 1 do not match.  Exiting.')
    return(invisible())
  }

  # Check that a vector of numeric constant pop sizes was entered
  if(class(popSizes)!="numeric"){
    warning("Population sizes must be numeric. Exiting.")
    return(invisible())
  }

  N=length(gtSample)  # number of gene trees in sample

  # Write out greeting in console
  cat(paste0("  Computing the theoretical and empirical pairwise distances between taxa ", taxon1,
             " and ", taxon2,".\n  The number of gene trees in the sample is ", N,".\n"))

  # include some timing for large gt datasets
  start_time <- Sys.time()

  # obtains distance in each gene tree betwen taxon1 and taxon2
  sampleDist=vector(mode = "numeric", length = N) # allocate space for sample distances
  for (z in 1:N)
  {
    tr=gtSample[[z]]  # get gene tree
    d=cophenetic(tr)  # compute distance table for given gene tree
    sampleDist[z]=d[taxon1,taxon2] # record the distance between the taxa of interest
  }
  current_time = Sys.time()
  elapsedTime=as.numeric(difftime(current_time,start_time,units="mins"))
  if (elapsedTime>4) {
    cat(paste0("  Time to read and process ",N," gene tree samples was ",round(elapsedTime,1)," minutes.\n"))
  }

  # create an empirical histogram for full sample for plotting later
  hg=hist(sampleDist, plot = FALSE, breaks = 100)

  # Create and plot theoretical pdf

  # invert the constant population sizes and save as functions
  # (overkill here but useful for nonconstant population sizes in future)
  invPopSizes=lapply(popSizes,invertPopSize)

  edgeLens=stree$edge.length

  # holds the edge numbers of the edges above taxon1 and taxon2
  ancestry=edgesabove(stree,taxon1,taxon2)
  ea1=edgesabove(stree,taxon1,taxon1)
  ea2=edgesabove(stree,taxon2,taxon2)

  # get edge numbers for the edges from taxon i to MRCA
  t1=ea1[!ea1 %in% ancestry]
  t2=ea2[!ea2 %in% ancestry]

  # compute the number of internal nodes above MRCA of taxon1, taxon2
  numInternalNodes=length(ancestry-1)

  # sum distances from internal nodes to two tips taxon1 and taxon2
  # entries will correspond to g_ab + 2*m_i in paper
  distancesAtInternalNodes=vector(mode = "numeric",length = numInternalNodes)
  distancesAtInternalNodes[1]=sum(stree$edge.length[t1],stree$edge.length[t2])
  if (numInternalNodes>1) {
    for (i in 2:numInternalNodes){
      distancesAtInternalNodes[i]=distancesAtInternalNodes[i-1]+2*edgeLens[ancestry[i-1]]
    }
  }

  # vector to hold the probabilities of no coalescence occuring before reaching
  # internal nodes. These are the products of what are called eta in paper.
  nocoalProbAtInternalNodes=vector(mode = "numeric", length = numInternalNodes)
  nocoalProbAtInternalNodes[1]=1
  if (numInternalNodes>1){
    for (i in 2:numInternalNodes){
      nocoalProbAtInternalNodes[i]=nocoalProbAtInternalNodes[i-1] *
        exp(-edgeLens[ancestry[i-1]]*invPopSizes[[ancestry[i-1]]](0) )
    }
  }
  # for debugging
  # ESA
  # ESA
  cat(paste0("\n"))
  print(nocoalProbAtInternalNodes[])

  # get the x values for plotting the theoretical distribution

  # get the minimal distance with non-zero support
  # do not get maximum distance since later this code will be adapted for non-ultrametric trees
  d=cophenetic(stree)
  xMin=d[taxon1,taxon2]

  # get xMax based on theoretical distribution and sample size N
  indRootPop=ancestry[numInternalNodes]

  # get x value that cuts of a tail of tailProb
  xMax=round(  distancesAtInternalNodes[numInternalNodes] -
                 2*log(tailProb/nocoalProbAtInternalNodes[numInternalNodes]) / (invPopSizes[[indRootPop]](0)) )
  cat(paste0("\n  Rounded percentage of sample pairwise distances > tailProb (", tailProb, "): ", round(sum(sampleDist>xMax)/N,3), ".\n"))

  xMax = max(xMax, ceiling(max(sampleDist)))

  xStepLength=(xMax-xMin)/(numSteps-1);
  xVals=seq(xMin,xMax,xStepLength)      # the domain of the pdf

  # allocate space for the theoretical density
  theorDensity <- vector(mode = "numeric", length = numSteps)

  # compute the theoretical density
  left=which.min(xVals>=distancesAtInternalNodes[1])
  # conditional makes sure the for loop counts up
  if (numInternalNodes>1) {
    for (i in 1:(numInternalNodes-1)){
      right=which.min(xVals<distancesAtInternalNodes[i+1])-1
      # Avoid silly mistake:  if numSteps is too small, then right < left possible
      if (right < left){
        warning("You must use a larger number of steps for a reasonable plot.")
        return()
      }
      inds=left:right
      xx=xVals[inds]
      theorDensity[inds]=nocoalProbAtInternalNodes[i]*
        ( exp(-(xx-distancesAtInternalNodes[i])*invPopSizes[[ancestry[i]]](0) /2)  ) *
             (invPopSizes[[ancestry[i]]](0)) / 2
      left=right+1
    }
  }
  xx=xVals[left:numSteps]
  inds=left:numSteps
  theorDensity[inds]=nocoalProbAtInternalNodes[numInternalNodes]*
    ( exp(-(xx-distancesAtInternalNodes[numInternalNodes]) * invPopSizes[[ancestry[numInternalNodes]]](0) / 2) ) *
          invPopSizes[[ancestry[numInternalNodes]]](0) / 2

  # Now plot both theoretical density and sample distances histogram
  title=paste0("Density of d(",taxon1,",",taxon2,") on gene trees")

  # plot theoretical density first
  plot(c(0,xVals[1],xVals),c(0,0,theorDensity),col="blue",lwd=2,type='l',
       xlab="Generations",ylab="density",main=title,ylim=c(0,max(theorDensity,hg$density)) )

  # plot empirical histogram for full sample
  plot(hg,xlab="Generations",freq=FALSE,add = TRUE)

  values=c(xMin,xMax,max(theorDensity),taxon1,taxon2)

  return(invisible(list(sampleDist,distancesAtInternalNodes,nocoalProbAtInternalNodes,
                        xMin,xMax,max(theorDensity),taxon1,taxon2,ancestry,invPopSizes)))
  # The returned list here contains information to be passed to the ADtest function if a formal
  # statistical test of the distribution fit is desired. These include
  # sampleDist: the vector of distances between taxon1 and taxon 2 from the sample
  # distancesAtInternalNodes: the sums of the 2 distances from taxon1 and taxon2 to ancestral internal nodes
  # nocoalProbAtInternalNodes: the probabilities of no coalescence between the two lineages below internal nodes
  # xMin: the smallest distance at which a coalescent event could occur
  # xMax: the largest distance which will be included in plot
  # max(theorDensity): The maximum of the theoretical density
  # ancestry: a vector of the edges ancestral to taxon1 and taxon2
}



#' Perform Anderson-Darling tests comparing sample and and theoretical pairwise distance distributions.
#'
#' Takes as input theoretical pairwise distance densities under the MSC and
#' empirical pairwise distances from gene trees in a sample, as returned by
#' the function \code{pairwiseDist}.  Uses the package \code{kSamples} to perform
#' either one test on the entire dataset or multiple tests on subsamples.
#'
#' @details
#' Anderson-Darling tests can perform poorly due to numerical issues when the sample size N is too large, so
#' an optional parameter \code{ADtestSize} can be set to create subsamples of smaller size.
#' When \code{ADtestSize} is a positive integer greater than 0, the number N of gene trees
#' for which the empirical density was computed is partitioned into sets of size \code{ADtestSize}.
#' Anderson-Darling tests are performed on each subset, comparing them to
#' a random sample of the same size from the theoretical distribution.
#'
#' @details
#' For a single test, output of test statistics and p-values are given as text. For multiple tests,
#' output is given as a histogram of p-values. Assuming good fit, the histogram should be
#' approximately uniform.
#'
#' @param distanceDensities A list containing values needed for performing Anderson-Darling
#' test(s) on a gene tree sample, as output by \code{pairwiseDist}.
#' The first entry of this list is \code{sampleDist},
#' a vector with entries the pairswise distances computed from gene trees in a sample.
#' This can be useful to practitioners.  Other entries in this list are documented in the code
#' for \code{pairwiseDist}.
#'
#' @param ADtestSize A positive integer or \code{FALSE}.  Default is \code{FALSE}, to use full sample for one test.
#'
#' @return Invisibly returns a sample from the theoretical density, of the same size as the empirical sample.
#'
#' @examples stree=read.tree(text="((((a:10000,b:10000):10000,c:20000):10000,d:30000):10000,e:40000);")
#' pops=c(15000,25000,10000,1,1,1,1,1,12000)
#' gts=read.tree(file=system.file("genetreeSample",package="MSCsimtester"))
#' distDen=pairwiseDist(stree,pops,gts,"a","b")
#' ADtest(distDen)
#' ADtest(distDen,1000)
#'
#' @seealso \code{\link{pairwiseDist}}
#'
#' @export
#'
ADtest = function(distanceDensities,ADtestSize=FALSE)
{
  # returned invisibly by pairwiseDist()
  # return(invisible(list(sampleDist,distancesAtInternalNodes,nocoalProbAtInternalNodes,
  #                       xMin,xMax,max(theorDensity),taxon1,taxon2,ancestry,invPopSizes)))

  empirSample=distanceDensities[[1]]
  distancesAtInternalNodes=distanceDensities[[2]]
  nocoalProbAtInternalNodes=distanceDensities[[3]]
  xMin=distanceDensities[[4]]
  xMax=distanceDensities[[5]]
  C=distanceDensities[[6]]
  taxon1=distanceDensities[[7]]
  taxon2=distanceDensities[[8]]
  ancestry=distanceDensities[[9]]
  invPopSizes=distanceDensities[[10]]

  # length of empircal density (= number of gene trees in sample)
  N = length(empirSample)

  numInternalNodes=length(distancesAtInternalNodes)
  distanceAtRoot=distancesAtInternalNodes[numInternalNodes]

  # # ESA
  print(distancesAtInternalNodes)
  print(nocoalProbAtInternalNodes)

  # Write out greeting in console
  if (ADtestSize==FALSE) {ADtestSize=N}
  if ((ADtestSize<=0) || (ADtestSize>N)) {
    warning('Test size for AD test must be positive and less than the number of gene trees.  Exiting.')
    return(invisible())
  }
  cat(paste0("  Anderson-Darling tests will be performed with samples of size ",ADtestSize,".\n"))

  # perform Anderson-Darling tests
  # compute number of AD tests to perform
  if (ADtestSize==N) {
    numTests=1
  }
  else {
    numTests=floor(N/ADtestSize)
  }

  # create sample from theoretical distribution
  theorSample <- vector(mode = "numeric", length = N)

  start_time = Sys.time()

  k <- 1 # sample counter
  while(k < N+1)
  {
    z <- runif(n=1,min=xMin,max=xMax)

    # compute pairwise density for z
    if (z>=distanceAtRoot) {
      ind=numInternalNodes
    }
    else {
      ind=which.min(z>=distancesAtInternalNodes)-1
    }
    R = nocoalProbAtInternalNodes[ind] *
        ( exp(-(z-distancesAtInternalNodes[ind])*invPopSizes[[ancestry[ind]]](0) /2) *
         invPopSizes[[ancestry[ind]]](0) / 2 )  / C

    if (R > runif(1))
    {
      theorSample[k] <- z
      k  <- k + 1
    }
  }

  current_time = Sys.time()
  elapsedTime=as.numeric(difftime(current_time,start_time,units="mins"))
  if (elapsedTime > 4) {
    cat(paste0("  Total time to compute ",k-1," samples from theoretical density was ",round(elapsedTime,1)," minutes.\n"))
  }

  pval=rep(0,numTests)  # variable to hold the p-values
  for(j in 1:numTests){
    # perform numTests ad.tests and save p-value
    subind=(1:ADtestSize)+(j-1)*ADtestSize
    s=ad.test(empirSample[subind], theorSample[subind])
    pval[j]=s$ad[1,3]
  }
  if(numTests==1) {
    print(s)
  }
  else {
    hist(pval,breaks=numTests,main="Anderson-Darling test results",xlab="p-values",freq = TRUE)
  }
  return(invisible(theorSample))
}


#' Compare expectations of topological rooted triples under the MSC to empirical ones in a sample.
#'
#' For a given species tree with population sizes, this function compares the expected frequencies
#' of rooted triples to empirical frequencies in a sample of gene trees using Chi^2 tests with 2 d.f.
#' The exact and estimated internal branch length (in coalescent units) of the rooted triple
#' in the species tree are also computed for comparison.  A single test can be performed
#' on the entire gene tree sample, or multiple tests on subsamples.
#'
#' @details
#' When \code{subsamplesize} is \code{FALSE} the Chi-squared test is performed using all
#' gene trees in \code{gtSample}. Results are reported in tabular form in the console.
#'
#' @details
#' When \code{subsamplesize} is a positive integer, the  N trees in \code{gtSample}
#' will be partitioned into subsets of size \code{floor(N/subsamplesize)}. A Chi-squared test is
#' performed for each subsample. Two histograms are plotted:  The first shows p-values for the Chi-squared tests on
#' subsamples. The second shows subsample estimates of the internal branch length for the rooted triple on the
#' species tree, with the true value marked.
#'
#' @details This function requires three distinct taxon names, all of which must occur on \code{stree}
#' and in each of the gene trees in the sample.
#'
#' @param stree An object of class \code{phylo} containing a rooted metric species tree.
#' Edge lengths are in number of generations.
#' @param popSizes An ordered list containing constant population sizes for each species tree edge, for a haploid organism.
#' Sizes should be doubled for diploids. If \code{stree} has k edges, then \code{popSizes} must have k+1 elements,
#' with the final entry for the population ancestral to the root.
#' @param gtSample An object of class \code{multiPhylo} holding a sample of gene trees from a simulation.
#' Taxon labels on gene trees must be identical to those on \code{stree}.
#' @param taxon1 A string specifying one taxon on \code{stree}.
#' @param taxon2 A string specifying a second taxon on \code{stree}, distinct from \code{taxon1}.
#' @param taxon3 A string specifying a third taxon on \code{stree}, distinct from \code{taxon1, taxon2}.
#' @param subsamplesize A positive integer or \code{FALSE}, giving size of subsamples of \code{gtSample} to analyze.
#'
#' @seealso \code{\link{edgeOrder}}, \code{\link{plotPops}}
#' @examples stree=read.tree(text="((((a:10000,b:10000):10000,c:20000):10000,d:30000):10000,e:40000);")
#' pops=c(15000,25000,10000,1,1,1,1,1,12000)
#' gts=read.tree(file=system.file("genetreeSample",package="MSCsimtester"))
#' rootedTriple(stree,pops,gts,"a","b","c")
#' rootedTriple(stree,pops,gts,"a","b","c",1000)
#' @export
#'
rootedTriple=function(stree,popSizes,gtSample,taxon1,taxon2,taxon3,subsamplesize=FALSE)
{

  # limited checking of arguments
  if(sum(duplicated(c(taxon1,taxon2,taxon3)))==1){
    warning('Taxa must be different.')
    return(invisible())
  }

  if(class(popSizes)!="numeric"){
    warning("Population sizes must be numeric. Exiting.")
    return(invisible())
  }
  else {
    invPopSizes=lapply(popSizes,invertPopSize)
  }

  if(subsamplesize==FALSE) subsamplesize=length(gtSample)

  droppedtips=stree$tip.label[ !stree$tip.label %in% c(taxon1,taxon2,taxon3) ]
  striplet=drop.tip(stree,droppedtips, root.edge = 0)

  numTests=floor(length(gtSample)/subsamplesize)
  pv=vector(mode = "numeric", length = numTests)
  intbrnch=vector(mode = "numeric", length = numTests)

  t1=read.tree(text=paste0("((",taxon1,",",taxon2,")",",",taxon3,");") )
  t2=read.tree(text=paste0("((",taxon1,",",taxon3,")",",",taxon2,");") )
  t3=read.tree(text=paste0("((",taxon3,",",taxon2,")",",",taxon1,");") )
  ttops=c(paste0("((",taxon1,",",taxon2,")",",",taxon3,");"),paste0("((",taxon1,",",taxon3,")",",",taxon2,");"),paste0("((",taxon3,",",taxon2,")",",",taxon1,");"))
  if(all.equal(striplet, t1, use.edge.length = FALSE) )
  {
    abo=edgesabove(stree,taxon1,taxon2)
    abo2=edgesabove(stree,taxon3,taxon2)
    abo=abo[!abo %in% abo2]
    cu=0;
    for(i in 1:length(abo))
    {
      cu=stree$edge.length[abo[i]]/popSizes[abo[i]]+cu
    }
    trip=c(2,3)
    tita=1
  }
  if (all.equal(striplet, t2, use.edge.length = FALSE) )
  {
    abo=edgesabove(stree,taxon1,taxon3)
    abo2=edgesabove(stree,taxon3,taxon2)
    abo=abo[!abo %in% abo2]
    cu=0;
    for(i in 1:length(abo))
    {
      cu=stree$edge.length[abo[i]]/popSizes[abo[i]]+cu
    }
    trip=c(1,3)
    tita=2
  }
  if(all.equal(striplet, t3, use.edge.length = FALSE) ){
    abo=edgesabove(stree,taxon3,taxon2)
    abo2=edgesabove(stree,taxon1,taxon2)
    abo=abo[!abo %in% abo2]
    cu=0; # Coalescent units
    for(i in 1:length(abo))
    {
      cu=stree$edge.length[abo[i]]/popSizes[abo[i]]+cu
    }
    trip=c(2,1)
    tita=3
  }
  ntop=c(1,2,3)[-tita]
  for(h in 1:numTests)
  {
    Q=matrix(0,subsamplesize,4) # array for 3 counts
    for (z in 1:subsamplesize)
    {
      t<-gtSample[[(h-1)*subsamplesize+z]]
      t=drop.tip(t,droppedtips, root.edge = 0)

      if (all.equal(t, t1, use.edge.length = FALSE))
      {
        Q[z,4] = 1
      }

      if (all.equal(t, t2, use.edge.length = FALSE))
      {
        Q[z,4] = 2
      }
      if (all.equal(t, t3, use.edge.length = FALSE))
      {
        Q[z,4] = 3
      }
    }
    s=Q
    s4=s[,4]
    c=rep(0,3)
    c[1]=sum(s4==1)
    c[2]=sum(s4==2)
    c[3]=sum(s4==3)
    cc=exp(-cu)/3
    d=-log(1.5*(c[trip[1]]+c[trip[2]])/subsamplesize)
    intbrnch[h]=d
    theo=c(subsamplesize*(1-2*cc),subsamplesize*cc,subsamplesize*cc)
    sim=c(c[tita],c[ntop[1]],c[ntop[2]])
    pv[h]=pchisq(sum((theo-sim)^2/theo),2, lower.tail = F)

  }
  if(numTests==1)
  {
    cat(sprintf("\n  Rooted triple topology counts on gene trees\n"))
    smmry <- matrix(c(subsamplesize*(1-2*cc),subsamplesize*cc,subsamplesize*cc,c[tita],c[ntop[1]],c[ntop[2]]),ncol=3,byrow=TRUE)
    colnames(smmry) <- c(ttops[tita],ttops[ntop[1]],ttops[ntop[2]])
    rownames(smmry) <- c('Expected counts:','Sample counts:')
    smmry <- as.table(smmry)
    print( smmry )

    cat(sprintf("  Chisq p-value: %g \n",pv[1]))

    cat(sprintf("\n  Branch length on rooted triple in species tree"))
    smmry2 <- matrix(c(cu,d),ncol=1,byrow=TRUE)
    rownames(smmry2) <- c('Species tree internal edge length (cu):','Estimated internal edge length (cu):')
    colnames(smmry2) <- c(' ')
    smmry2 <- as.table(smmry2)
    print( smmry2 )
  } else
  {
    str=paste0("Chi^2 test results on samples of size ",subsamplesize)
    hist(pv,breaks = numTests, xlab="p-values for rooted triple tests",freq = TRUE,main=str)
    hh=hist(intbrnch,breaks = numTests/2, main="Internal branch length estimates",xlab="Coalescent units",freq = TRUE)
    xV=rep(cu,2)
    yV=c(-.2,.05*max(hh$density))
    lines(xV,yV,lwd=4,col="blue")
  }
}



# This function determines the edges above two taxa.
# It returns list of edge numbers, from the MRCA to the root
#
edgesabove=function(stree,tx1,tx2)
{
  MRCA=mrca(stree, full = FALSE) #compute full array so also works for tx1=tx2 (getMRCA requires distinct taxa)
  MRCA=MRCA[tx1,tx2]
  ancestry=MRCA
  flag=length(which(stree$edge[,2]==MRCA))
  p=1
  while(flag==1)
  {
    ancestry[p+1]=stree$edge[which(stree$edge[,2]==ancestry[p])]
    flag=length(stree$edge[which(stree$edge[,2]==ancestry[p+1])])
    p=p+1
  }
  edge.ancestry=1
  for( i in  1:length(ancestry))
  {
    if(length(which(stree$edge[,2]==ancestry[i]))==1)
      edge.ancestry[i] =  which(stree$edge[,2]==ancestry[i])
    else {
      edge.ancestry[i]=nrow(stree$edge)+1
    }
  }
  return(edge.ancestry)
}


# invert a numerical population size and make it a function
invertPopSize = function(pp)
{
  xx <- local({
    function(x){1/(pp+x*0)}
  })
  return(xx)
}



