#' Produce table of counts of quartets displayed on trees
#'
#' Compiles table of counts of topological quartets displayed on a collection of trees.
#' The taxa on the trees may be any set overlapping with taxanames.
#' Branch lengths of non-negative size less than or equal to epsilon are treated as zero,
#' giving polytomies.
#'
#' @details
#' Error if any branch length <0; Warnings if some of taxa names are missing on some trees, or
#' if some 4-taxon set is on no trees.
#'
#' If \code{random}>0, then for efficiency it should be much smaller then
#' the number of possible 4 taxon subsets.
#'
#' @param trees multiphylo object containing un/rooted metric/topological trees
#' @param taxanames vector of names of taxa of interest, of length n
#' @param epsilon minimum for branch lengths to be treated as non-zero
#' @param random number of random subsets of 4 taxa to consider; if 0, use all N choose 4 subsets
#' @return
#'     A (\code{n} choose 4)x(\code{n}+4) matrix (or \code{random}x(\code{n}+4) matrix) encoding
#'     4 taxon subsets of taxanames and counts of each of the
#'     quartets 12|34, 13|24, 14|23, 1234 across the trees. Columns are labeled by taxa names and
#'     quartet names("12|34", etc.). 1s and 0s in taxon columns indicate the taxa in quartet.
#'     Quartet 12|34
#'     means first and second indicated taxa form cherry, 13|24 means first and third form cherry, 14|23 means
#'     first and fourth form cherry, and 1234 means unresolved
#' @seealso \code{\link{ResolvedQuartetTable}}, \code{\link{DominantQuartetTable}}
#'
#' @examples
#' gts=read.tree(file=system.file("genetreeSample",package="MSCquartet"))
#' taxanames=AllTaxa(gts)
#' QT=QuartetTable(taxanames[1:5],gts)
#' RQT=ResolvedQuartetTable(QT)
#' DQT=DominantQuartetTable(RQT)
#'
#' @importFrom ape cophenetic.phylo compute.brlen
#'
#' @export
QuartetTable = function(taxanames,
                        trees,
                        epsilon = 0,
                        random = 0) {
  if (random < 0)
    stop("Parameter 'random' must be non-negative.")
  random = round(random)
  
  taxanames = sort(taxanames) #put taxa in fixed order
  nt = length(trees) # number of gene trees
  N = length(taxanames) # number of taxa
  if (random > 0)
    M = random # number of 4-taxon sets to consider
  else
    M = choose(N, 4)
  Q = matrix(0, M, N + 4) #allocate space for table
  qnames = c("12|34", "13|24", "14|23", "1234")
  colnames(Q) = c(taxanames, qnames) #create column names
  warnMissing = 0 # flag for some taxa not on all gene trees
  
  
  # encode 4-taxon sets in matrix
  if (random == 0) {
    #use all subsets of 4
    m = 0
    for (i in 1:(N - 3)) {
      # for each 4-taxon set
      for (j in (i + 1):(N - 2)) {
        for (k in (j + 1):(N - 1)) {
          for (l in (k + 1):N) {
            m = m + 1
            Q[m, c(i, j, k, l)] = 1 #encode set
          }
        }
      }
    }
  }
  else {
    #use random sets of 4 taxa
    i = 1
    while (i <= random)  {
      q = sample(N, size = 4, replace = FALSE)# 4 random taxa
      row = integer(N) # encode as 0/1 vector
      row[q] = 1
      
      j = 1 #check earlier rows for repeated quartet
      while (j < i) {
        if (identical(Q[j, 1:N], row))
          j = i + 1 #set flag for match
        else
          j = j + 1 # go to next row
      }
      if (j == i) {
        # accept this choice of 4 taxa
        Q[i, 1:N] = row
        i = i + 1
      }
    }
  }
  
  print(paste0( 'Counting occurances of displayed quartets for ',M,' subsets of 4 taxa for ',N,' taxa across ',nt,' gene trees.'))
  
  for (numt in 1:nt) {
    # for each gene tree
    t = trees[[numt]] #get next tree
    if (is.null(t$edge.length)) {
      t = compute.brlen(t, 1) #if no branch lengths then make them all 1
    } else {
      if (sum(t$edge.length < 0) > 0)
        stop("Error: Negative branch length in tree") #if any negative lengths abort
    }
    
    zeros = which(t$edge.length <= epsilon) # find locations of any zero branch lengths
    t$edge.length[] = 1 # set all lengths to 1, to avoid numerical error in 4-point below
    t$edge.length[zeros] = 0  # reset zeros to 0
    
    d = cophenetic.phylo(t) # get distance matrix for the tree
    for (m in 1:M) {
      # for each 4-taxon set
      tax = as.character(taxanames[which(Q[m, 1:N] == 1)]) # names of 4 taxa (or fewer)
      if (all(tax %in% colnames(d))) {
        # if all 4 taxa present on this tree
        a = d[tax[1], tax[2]] + d[tax[3], tax[4]] # use 4-point condition
        b = d[tax[1], tax[3]] + d[tax[2], tax[4]]  #    to determine quartet
        c = d[tax[1], tax[4]] + d[tax[2], tax[3]]  #
        z = sort(c(a, b, c))
        if (z[1] == z[2]) {
          # tie means a polytomy
          Q[m, "1234"] = Q[m, "1234"] + 1
        } else {
          if (z[1] == a) {
            #quartet is ab|cd
            Q[m, "12|34"] = Q[m, "12|34"] + 1
          } else {
            if (z[1] == b) {
              #quartet is ac|bd
              Q[m, "13|24"] = Q[m, "13|24"] + 1
            } else {
              Q[m, "14|23"] = Q[m, "14|23"] + 1
            } #quartet is ad|bc
          }
        }
      } else
        warnMissing = 1 # some taxa not on this tree
    }
  }
  
  if (warnMissing == 1)
    warning("Some taxa missing from some trees.")
  if ((N > 4) && (sum(rowSums(Q[, qnames, drop = FALSE]) == 0) > 0))
    warning("Some 4-taxon set not present on any tree.")
  if (sum(Q[, "1234"]) > 0)
    warning("Some quartets unresolved.")
  
  return(Q)
}

#################################################

#' Produce table of counts of quartets, only showing resolved ones
#'
#' Converts table of all quartet counts, including unresolved, by either dropping unresolved ones, or
#' distributing them uniformly among resolved
#'
#' @param QT table as produced by \code{QuartetTable} of size (n choose 4)x(n+4)
#' @param omit TRUE deletes unresolved quartets column,
#'            FALSE redistributes unresolved counts as (1/3,1/3,1/3) to resolved counts
#' @return
#'      A table of size (n choose 4)x(n+3), similar to QuartetTable
#'
#' @examples
#' gts=read.tree(file=system.file("genetreeSample",package="MSCquartet"))
#' taxanames=AllTaxa(gts)
#' QT=QuartetTable(taxanames[1:5],gts)
#' RQT=ResolvedQuartetTable(QT)
#' DQT=DominantQuartetTable(RQT)
#'
#' @seealso \code{\link{QuartetTable}}, \code{\link{DominantQuartetTable}}
#' @export
ResolvedQuartetTable = function(QT, omit = FALSE) {
  RT = QT[, -which(colnames(QT) == "1234"), drop = FALSE]  #copy table without unresolved column
  if (omit == FALSE) {
    qs = c("12|34", "13|24", "14|23") #columns to be adjusted
    RT[, qs] = RT[, qs, drop = FALSE] + QT[, "1234", drop = FALSE] %*% matrix(1 / 3, 1, 3) #redistribute counts
  }
  return(RT)
}

#################################################


#' Produce table of dominant quartets, with ML estimates of internal edge length under the MSC model
#'
#' Converts table of counts of resolved quartets on \code{n} taxa to show only dominant one, with
#' maximum likelihood estimate of internal edge weight under the multispecies
#' coalescent model.
#'
#' @param RQT array as produced by \code{ResolvedQuartetTable} of size (n choose 4)x(n+3);
#'
#' @return
#'   An (n choose 4)x(n+1) array with dominant quartet topology encoded by 1,1,-1,-1 in
#' taxon columns, with signs indicating cherries. Column "weight" contains ML estimate
#' under MSC model of quartets central edge length, in coalescent units.
#'
#' @examples
#' gts=read.tree(file=system.file("genetreeSample",package="MSCquartet"))
#' taxanames=AllTaxa(gts)
#' QT=QuartetTable(taxanames[1:5],gts)
#' RQT=ResolvedQuartetTable(QT)
#' DQT=DominantQuartetTable(RQT)
#'
#' @seealso \code{\link{QuartetTable}}, \code{\link{ResolvedQuartetTable}}
#' @importFrom stats runif
#' @export
DominantQuartetTable = function(RQT) {
  M = dim(RQT)[1] # number of 4-taxon sets
  N = dim(RQT)[2] - 3 # number of taxa
  taxanames = colnames(RQT)[1:N] # names of taxa
  
  DQT = matrix(0, M, N + 1) # allocate space for most frequent quartet topologies and weight
  for (m in 1:M) {
    # for each 4-taxon set
    DQT[m, 1:N] = RQT[m, 1:N] # save taxa (some 1s to be flipped to -1 later)
    taxa = which(RQT[m, 1:N] == 1) # taxa numbers
    z = RQT[m, (N + 1):(N + 3)] # frequencies of quartets
    tz = sum(z) # total number of quartets
    if (tz > 0) {
      # if some quartets were found
      mq = which.max(RQT[m, (N + 1):(N + 3)] + runif(3)) # which is biggest? (random tie-breaking)
      if (mq == 1) {
        DQT[m, c(taxa[3], taxa[4])] = -1
      } else {
        if (mq == 2) {
          DQT[m, c(taxa[2], taxa[4])] = -1
        } else {
          DQT[m, c(taxa[2], taxa[3])] = -1
        }
      }
      f = z[mq] / tz #relative frequency of most frequent quartet
      f = min(f, (tz - .5) / tz) # reduce a little if f was 1
      DQT[m, N + 1] = -log((1.5 * (1 - f))) # save weight
    }
  }
  colnames(DQT) = c(taxanames, "weight") #add column names
  return(DQT)
}

#' Get all taxon names on a collection of trees
#'
#' Create a list of all taxa names appearing on a collection of trees, with no repeats.
#'
#' @param trees a multiphylo object containing a collection of trees
#'
#' @return a vector of unique names of taxa appearing on the trees
#'
#' @examples
#' gts=read.tree(file=system.file("genetreeSample",package="MSCquartet"))
#' taxanames=AllTaxa(gts)
#'
#' @export
AllTaxa = function(trees) {
  taxa = c()
  for (i in 1:length(trees)) {
    taxa = union(taxa, trees[[1]]$tip.label)
  }
  return(taxa)
}