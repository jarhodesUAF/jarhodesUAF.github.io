#' Compute Quartet Distance between taxa
#'
#' Compute the Quartet Distance of [R19] from a table specifying a collection of quartets  on
#' \code{n} taxa.
#'
#' @param DQT an (\code{n} choose 4) x \code{n} (or \code{n+1}) matrix of form output by \code{DominantQuartetTable}
#' (Note: \code{n+1}th column of DQT is ignored)
#' @return
#'     A pairwise distance matrix on \code{n} taxa
#' @seealso \code{\link{DominantQuartetTable}},
#' \code{\link{QDS}},
#' \code{\link{QDCf}},
#'          \code{\link{QDCf}},
#'          \code{\link{WQdist}}
#'
#' @examples
#' gtrees=read.tree(file=system.file("genetreeSample",package="MSCquartets"))
#' taxanames=AllTaxonNames(gtrees)
#' QT=QuartetTable(taxanames[1:5],gtrees)
#' RQT=ResolvedQuartetTable(QT)
#' DQT=DominantQuartetTable(RQT)
#' Dist=Qdist(DQT)
#' tree=NJ(Dist)
#'
#' @export
Qdist = function(DQT) {
  Qcolnames = colnames(DQT)# get column names
  n = length(Qcolnames) - 1# number of taxa
  taxa = Qcolnames[1:n]# names of taxa
  m = dim(DQT)[1]# number of quartets
  
  D = matrix(0, n, n)# create distance matrix
  colnames(D) = taxa
  rownames(D) = taxa
  
  for (i in 1:m) {
    ones = which(DQT[i,] == 1)
    if (length(ones) == 2) {
      # skip null quartets
      nones = which(DQT[i,] == -1)
      D[ones, nones] = D[ones, nones] + 1 # increment 4 entries of D
      D[nones, ones] = D[nones, ones] + 1 # and another 4
    }
  }
  
  D = 2 * D + 2 * n - 4 # adjust to appropriate Q distance
  for (i in 1:n) {
    D[i, i] = 0 # and unadjust diagonal back to 0
  }
  return(D)
}

###################################################################

#' Compute Quartet Distance Supertree
#'
#' Apply the Quartet Distance Supertree method of [R19] to a table specifying a
#' collection of quartets on \code{n} taxa.
#'
#' @details This function is a wrapper which runs \code{Qdist} and then builds a tree.
#'
#' @param DQT an (\code{n} choose 4) x \code{n} (or \code{n+1}) matrix of form output by \code{DominantQuartetTable}
#' (Note: \code{n+1}th column of DQT is ignored)
#' @param method tree building method function (fastme.bal, nj, etc.)
#' @return
#'     An unrooted metric tree (type phylo)
#' @seealso \code{\link{DominantQuartetTable}},
#' \code{\link{Qdist}},
#'          \code{\link{QDCf}},
#'          \code{\link{WQDS}}
#'
#' @examples
#' gtrees=read.tree(file=system.file("genetreeSample",package="MSCquartets"))
#' taxanames=AllTaxonNames(gtrees)
#' QT=QuartetTable(taxanames[1:5],gtrees)
#' RQT=ResolvedQuartetTable(QT)
#' DQT=DominantQuartetTable(RQT)
#' tree=QDS(DQT)
#'
#' @importFrom ape fastme.bal
#'
#' @export
QDS = function(DQT,
               method = fastme.bal) {
  D = Qdist(DQT)
  QDS = unroot(method(D))# build tree
  return(QDS)
}

#################################################

#' Compute the Weighted Quartet Distance between taxa
#'
#' Compute the Weighted Quartet Distance between taxa of [YR19] from a table specifying a collection of quartets on
#' \code{n} taxa and the quartets' internal branch lengths.
#'
#' @param DQT an (\code{n} choose 4) x \code{n+1}) matrix of form output by \code{DominantQuartetTable}
#'
#' @return
#'     A pairwise distance matrix on \code{n} taxa
#'
#' @seealso \code{\link{DominantQuartetTable}},
#'           \code{\link{WQDCAdjustLengths}},
#'           \code{\link{WQDS}},
#'           \code{\link{WQDCf}},
#'           \code{\link{Qdist}}
#'
#' @examples
#' gtrees=read.tree(file=system.file("genetreeSample",package="MSCquartets"))
#' taxanames=AllTaxonNames(gtrees)
#' QT=QuartetTable(taxanames[1:5],gtrees)
#' RQT=ResolvedQuartetTable(QT)
#' DQT=DominantQuartetTable(RQT,bigweights="finite")
#' D=WQdist(DQT)
#' tree=NJ(D)
#' stree=WQDCAdjustLengths(tree)
#'
#' @export
WQdist = function(DQT) {
  Qcolnames = colnames(DQT)# get column names
  n = length(Qcolnames) - 1# number of taxa
  taxa = Qcolnames[1:n]# names of taxa
  m = dim(DQT)[1]# number of quartets
  w = DQT[, n + 1]# weights
  
  D = matrix(2, n, n)# create distance matrix
  colnames(D) = taxa
  rownames(D) = taxa
  
  for (i in 1:m) {
    ones = which(DQT[i, ] == 1)
    if (length(ones) == 2) {
      # skip null quartets
      nones = which(DQT[i, ] == -1)
      D[ones, nones] = D[ones, nones] + w[i] # increment 4 entries of D
      D[nones, ones] = D[nones, ones] + w[i] # and another 4
    }
  }
  
  for (i in 1:n) {
    D[i, i] = 0 # unadjust diagonal back to 0
  }
  return(D)
}


#################################################

#' Compute the Weighted Quartet Distance Supertree tree
#'
#' Apply the Weighted Quartet Distance Supertree method of [YR19] to
#' a collection of quartets on\code{n} taxa together with internal quartet branch lengths, specified by a table
#'
#' @details This function is a wrapper which runs \code{WQdist}, builds a tree, and then adjusts edge lengths
#' with \code{WQDCAdjustLengths}.
#'
#' @param DQT an (\code{n} choose 4) x \code{n+1}) matrix of form output by \code{DominantQuartetTable}
#' @param method tree building method function (fastme.bal, NJ, etc.)
#'
#' @return
#'     An unrooted metric tree (type phylo)
#' @seealso \code{\link{DominantQuartetTable}},
#' \code{\link{WQdist}},
#'           \code{\link{WQDCAdjustLengths}},
#'           \code{\link{WQDCf}},
#'           \code{\link{QDS}}
#'
#' @examples
#' gtrees=read.tree(file=system.file("genetreeSample",package="MSCquartets"))
#' taxanames=AllTaxonNames(gtrees)
#' QT=QuartetTable(taxanames[1:5],gtrees)
#' RQT=ResolvedQuartetTable(QT)
#' DQT=DominantQuartetTable(RQT)
#' tree=WQDS(DQT)
#'
#' @importFrom ape fastme.bal
#' @export
WQDS = function(DQT,
                method = fastme.bal) {
  D = WQdist(DQT)# compute distance
  WQDS = unroot(method(D))# build tree
  return(WQDS)
}

#################################################

#' Adjust edge lengths on tree produced by WQDC/WQDS to estimate metric tree
#'
#' Modify edge lengths of WQDC tree to remove scaling factors related to the topology, giving
#' an estimate of the metric tree.
#'
#' @details As explained in [YR19], the metric tree produced by WQDC/WQDS has edge lengths
#' inflated by a factor dependent on the associated split size. Dividing by these factors yields a consistent estimate of
#' the metric species tree when WQDC is applied to a collection of gene trees under the multispecies coalescent model.
#'
#' @param tree an unrooted metric tree, such as output from WQDS
#' @return
#'       An unrooted metric tree (type phylo)
#' @seealso \code{\link{WQDS}},
#' \code{\link{WQDCf}}
#'
#' @examples
#' gtrees=read.tree(file=system.file("genetreeSample",package="MSCquartets"))
#' taxanames=AllTaxonNames(gtrees)
#' QT=QuartetTable(taxanames[1:5],gtrees)
#' RQT=ResolvedQuartetTable(QT)
#' DQT=DominantQuartetTable(RQT,bigweights="finite")
#' D=WQdist(DQT)
#' tree=NJ(D)
#' stree=WQDCAdjustLengths(tree)
#'
#' @importFrom ape is.rooted unroot root
#' @importFrom phangorn Descendants
#' @export
WQDCAdjustLengths = function(tree) {
  if (is.rooted(tree) == TRUE) {
    print("Tree is rooted; unrooting it")
    tree = unroot(tree)
  }
  ntree = root(tree, outgroup = tree$tip.label[1])
  ntaxa = length(ntree$tip.label)
  nedges = dim(ntree$edge)[1]
  for (i in 1:nedges) {
    node = ntree$edge[i, 2] # get child of edge
    ndesc = length(Descendants(ntree, node, "tips")[[1]])# count descendents, using phangorn function
    if (ndesc == 1) {
      ntree$edge.length[i] = 1
    }
    else if (ndesc == ntaxa - 1) {
      ntree$edge.length[i] = 0
    }
    else {
      ntree$edge.length[i] = ntree$edge.length[i] / ((ndesc - 1) * (ntaxa - ndesc - 1)) # adjust edge length
    }
  }
  
  WQDCAdjustLengths = unroot(ntree)
  return(WQDCAdjustLengths)
}


#################################################


#' Compute QDC tree from file of trees
#'
#' Compute the Quartet Distance Consensus [R19] estimate of a species tree from a file of gene trees
#'
#' @details This function is a wrapper which performs the the steps of reading in a collection
#' of gene trees, tallying quartets, computing the quartet distanace between taxa, and building
#' a tree which consistently estimates the species tree topology under the multispecies coalescent model.
#'
#' @param treefile  a file containing gene trees in Newick
#' @param taxanames list of taxa to construct tree on, can be subset of those on trees; if NULL, uses taxa on first gene tree in file
#' @param omit TRUE ignores unresolved quartets, FALSE treats them as 1/3 of each resolution.
#' @return an unrooted tree
#' @seealso \code{\link{QuartetTable}},
#'          \code{\link{ResolvedQuartetTable}},
#'          \code{\link{DominantQuartetTable}},
#'          \code{\link{Qdist}},
#'          \code{\link{QDS}},
#'          \code{\link{WQDCf}}
#'
#' @examples
#' stree=QDCf(treefile=system.file("genetreeSample",package="MSCquartets"))
#'
#' @export
QDCf = function(treefile,
                taxanames = NULL,
                omit = FALSE) {
  genetrees <- read.tree(treefile)
  if (is.null(taxanames)) {
    # if no taxa names specified,
    taxanames = genetrees[[1]]$tip.label   # ... get them from first tree
  }
  Q = DominantQuartetTable(ResolvedQuartetTable(QuartetTable(taxanames, genetrees), omit))
  return(QDS(Q))
}


#############################################################

#' Compute WQDC (edge length adjusted) tree from file of trees
#'
#' Compute the Weighted Quartet Distance Consensus [YR19] estimate of a species tree from a file of gene trees,
#' adjusting so internal edge lengths estimate those on species tree
#'
#' @details This function is a wrapper which performs the the steps of reading in a collection
#' of gene trees, tallying quartets, estimating quartet internal branch lengths, computing the weighted
#' quartet distanace between taxa, building
#' a tree, and adjusting edge lengths, to give a consistent estimate of the metric species tree
#' under the multispecies coalescent model.
#'
#' @param treefile  a file containing gene trees in Newick
#' @param taxanames list of taxa to construct tree on; may be subset of those on gene trees
#' @param omit TRUE leaves out unresolved quartets, FALSE treats them as 1/3 of each resolution.
#' @return an unrooted tree, with internal edge lengths the inferred lengths for the species tree
#' @seealso \code{\link{QuartetTable}},
#'          \code{\link{ResolvedQuartetTable}},
#'          \code{\link{DominantQuartetTable}},
#'          \code{\link{WQdist}},
#'          \code{\link{WQDS}},
#'          \code{\link{QDCf}}
#'
#' @examples
#' stree=WQDCf(treefile=system.file("genetreeSample",package="MSCquartets"))
#'
#' @export
WQDCf = function(treefile,
                 taxanames = NULL,
                 omit = FALSE) {
  genetrees <- read.tree(treefile)
  if (is.null(taxanames)) {
    # if no taxa names specified,
    taxanames = genetrees[[1]]$tip.label   # ... get them from first tree
  }
  Q = DominantQuartetTable(ResolvedQuartetTable(QuartetTable(taxanames, genetrees), omit),bigweights="finite")
  WQDCf = WQDCAdjustLengths(WQDS(Q))
}
